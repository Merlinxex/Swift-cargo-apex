import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import {
  PhoneCall, MessageSquare, MessageSquareText, MessagesSquare, Mail, Phone, Radio,
  Smartphone, Film, Image as ImageIcon, Sparkles, Video, IdCard, FileText, FileCheck,
  Loader2, Wallet, ArrowRight, Package, TrendingUp, Crown, Zap, ShieldCheck, RefreshCw, Star, Lock,
  type LucideIcon,
} from "lucide-react";
import type { ShopProduct } from "@/data/products";

const iconMap: Record<string, LucideIcon> = {
  PhoneCall, MessageSquare, MessageSquareText, MessagesSquare, Mail, Phone, Radio,
  Smartphone, Film, Image: ImageIcon, Sparkles, Video, IdCard, FileText, FileCheck,
  Package, TrendingUp, Crown, Zap, ShieldCheck, RefreshCw, Star, Lock,
};

const toneMap: Record<ShopProduct["tone"], string> = {
  blue: "bg-primary/15 text-primary border-primary/30",
  teal: "bg-success/15 text-success border-success/30",
  amber: "bg-warning/15 text-warning border-warning/30",
  violet: "bg-accent-violet/15 text-accent-violet border-accent-violet/30",
  green: "bg-success/15 text-success border-success/30",
  red: "bg-destructive/15 text-destructive border-destructive/30",
};

interface Props {
  products: ShopProduct[];
  whatsappNumber: string;
  /** Word used in prewritten message, e.g. "I want textplus" */
  buildMessage?: (p: ShopProduct) => string;
}

export const ProductGrid = ({ products, whatsappNumber, buildMessage }: Props) => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [balance, setBalance] = useState<number | null>(null);
  const [loadingId, setLoadingId] = useState<string | null>(null);

  useEffect(() => {
    if (!user) {
      setBalance(null);
      return;
    }
    const load = async () => {
      const { data } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) setBalance(Number(data.balance));
    };
    void load();

    const channel = supabase
      .channel(`wallet-grid-${user.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "wallets", filter: `user_id=eq.${user.id}` },
        (payload) => {
          const next = (payload.new as { balance?: number } | null)?.balance;
          if (typeof next === "number") setBalance(Number(next));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const handleBuy = async (p: ShopProduct) => {
    if (!user) {
      toast({ title: "Sign in required", description: "Please sign in to purchase." });
      navigate("/auth");
      return;
    }
    if (balance === null) {
      toast({ title: "Loading wallet…", description: "Please wait a moment." });
      return;
    }
    if (balance < p.price) {
      toast({
        title: "Insufficient balance",
        description: `You need $${p.price.toFixed(2)} but only have $${balance.toFixed(2)}. Top up your wallet.`,
        variant: "destructive",
      });
      return;
    }

    setLoadingId(p.id);
    let whatsappOpened = false;

    try {
      const message = buildMessage ? buildMessage(p) : `hi I want ${p.name}`;
      const url = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

      // Open WhatsApp FIRST (must be in user-gesture).
      // On mobile, window.open is often blocked — fall back to same-tab redirect.
      const win = window.open(url, "_blank", "noopener,noreferrer");
      whatsappOpened = true;
      if (!win) {
        window.location.href = url;
      }

      // Deduct balance
      const newBalance = Number((balance - p.price).toFixed(2));
      const { data: wallet } = await supabase
        .from("wallets")
        .select("total_spent")
        .eq("user_id", user.id)
        .maybeSingle();

      const { error: wErr } = await supabase
        .from("wallets")
        .update({
          balance: newBalance,
          total_spent: Number(wallet?.total_spent ?? 0) + p.price,
        })
        .eq("user_id", user.id);
      if (wErr) throw wErr;

      const { error: tErr } = await supabase.from("transactions").insert({
        user_id: user.id,
        type: "charge",
        amount: -p.price,
        description: `Purchase: ${p.name}`,
        metadata: { product_id: p.id, product_name: p.name, whatsapp: whatsappNumber },
      });
      if (tErr) throw tErr;

      setBalance(newBalance);
      toast({
        title: "Order confirmed",
        description: `$${p.price.toFixed(2)} deducted. WhatsApp opened.`,
      });
    } catch (e) {
      console.error(e);
      // WhatsApp already opened — don't show an error, the order went through
      if (whatsappOpened) {
        toast({
          title: "Order confirmed",
          description: `$${p.price.toFixed(2)} deducted. WhatsApp opened.`,
        });
      } else {
        toast({
          title: "Order failed",
          description: e instanceof Error ? e.message : "Something went wrong.",
          variant: "destructive",
        });
      }
    } finally {
      setLoadingId(null);
    }
  };

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
      {products.map((p, i) => {
        const Icon = iconMap[p.icon] ?? Sparkles;
        const isLoading = loadingId === p.id;
        return (
          <article
            key={p.id}
            className="group relative p-5 rounded-2xl glass hover:border-primary/50 transition-all duration-500 hover:-translate-y-1 hover:shadow-glow flex flex-col animate-fade-in-up"
            style={{ animationDelay: `${i * 50}ms` }}
          >
            <div className="absolute inset-0 rounded-2xl bg-gradient-aurora opacity-0 group-hover:opacity-[0.07] transition-opacity duration-500 pointer-events-none" />

            <div className="relative flex items-start justify-between gap-3 mb-3">
              <div className={cn("h-11 w-11 rounded-xl grid place-items-center border", toneMap[p.tone])}>
                <Icon className="h-5 w-5" />
              </div>
              {p.badge && (
                <span className="inline-flex items-center px-2.5 py-1 rounded-md text-[10px] font-bold border border-warning/40 bg-warning/10 text-warning uppercase tracking-wider">
                  {p.badge}
                </span>
              )}
            </div>

            <h3 className="relative font-display font-semibold text-base">{p.name}</h3>
            <p className="relative text-sm text-muted-foreground mt-1 leading-relaxed flex-1">
              {p.description}
            </p>

            <div className="relative mt-4 pt-4 border-t border-border/60 flex items-center justify-between gap-3">
              <div>
                <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Price</p>
                <p className="font-display font-bold text-xl text-gradient">${p.price.toFixed(2)}</p>
              </div>
              <Button
                variant="glow"
                size="sm"
                disabled={isLoading}
                onClick={() => handleBuy(p)}
              >
                {isLoading ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin" /> Processing…
                  </>
                ) : (
                  <>
                    Order <ArrowRight className="h-3.5 w-3.5" />
                  </>
                )}
              </Button>
            </div>
          </article>
        );
      })}

      {user && (
        <div className="sm:col-span-2 lg:col-span-3 mt-2 flex items-center justify-center gap-2 text-xs text-muted-foreground">
          <Wallet className="h-3.5 w-3.5" />
          Wallet balance: <span className="text-success font-semibold">${(balance ?? 0).toFixed(2)}</span>
        </div>
      )}
    </div>
  );
};
