import { useState, useEffect, useRef } from "react";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2, ArrowLeft, Bitcoin, ShieldCheck, Sparkles, ExternalLink, CheckCircle2 } from "lucide-react";
import { cn } from "@/lib/utils";

const USD_TO_XAF = 600;

type PaymentMethod = {
  id: "mtn" | "orange" | "binance";
  name: string;
  description: string;
  category: "Mobile" | "Crypto";
  iconBg: string;
  iconRing: string;
  monogram: string;
  monogramColor: string;
  minAmount: number;
  provider: "fapshi" | "manual";
};

const METHODS: PaymentMethod[] = [
  {
    id: "mtn",
    name: "MTN Mobile Money",
    description: "Fast & reliable mobile wallet",
    category: "Mobile",
    iconBg: "bg-[#FFCC00]",
    iconRing: "ring-[#FFCC00]/30",
    monogram: "MTN",
    monogramColor: "text-black",
    minAmount: 3,
    provider: "fapshi",
  },
  {
    id: "orange",
    name: "Orange Money",
    description: "Send money instantly",
    category: "Mobile",
    iconBg: "bg-[#FF6B00]",
    iconRing: "ring-[#FF6B00]/30",
    monogram: "O",
    monogramColor: "text-white",
    minAmount: 3,
    provider: "fapshi",
  },
  {
    id: "binance",
    name: "Pay ID (Binance)",
    description: "Crypto payments via Binance",
    category: "Crypto",
    iconBg: "bg-[#1a1a1a] border border-[#F0B90B]",
    iconRing: "ring-[#F0B90B]/30",
    monogram: "◈",
    monogramColor: "text-[#F0B90B]",
    minAmount: 5,
    provider: "manual",
  },
];

interface TopUpDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  userId: string;
  currentBalance: number;
  onSuccess: () => void | Promise<void>;
}

type Step = "method" | "details" | "pending";

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const ANON_KEY = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY;

export const TopUpDialog = ({ open, onOpenChange, userId, currentBalance, onSuccess }: TopUpDialogProps) => {
  const { toast } = useToast();
  const [step, setStep] = useState<Step>("method");
  const [method, setMethod] = useState<PaymentMethod | null>(null);
  const [amount, setAmount] = useState("3");
  const [reference, setReference] = useState(""); // binance only
  const [submitting, setSubmitting] = useState(false);
  const [transId, setTransId] = useState<string | null>(null);
  const [paymentLink, setPaymentLink] = useState<string | null>(null);
  const [pendingStatus, setPendingStatus] = useState<"waiting" | "success" | "failed" | "expired">("waiting");
  const pollRef = useRef<number | null>(null);

  const reset = () => {
    setStep("method");
    setMethod(null);
    setAmount("3");
    setReference("");
    setSubmitting(false);
    setTransId(null);
    setPaymentLink(null);
    setPendingStatus("waiting");
    if (pollRef.current) {
      window.clearInterval(pollRef.current);
      pollRef.current = null;
    }
  };

  const handleClose = (next: boolean) => {
    if (!next) reset();
    onOpenChange(next);
  };

  useEffect(() => {
    return () => {
      if (pollRef.current) window.clearInterval(pollRef.current);
    };
  }, []);

  const selectMethod = (m: PaymentMethod) => {
    setMethod(m);
    setAmount(String(m.minAmount));
    setStep("details");
  };

  const callFapshi = async (action: string, body: Record<string, unknown>) => {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/fapshi-proxy`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${ANON_KEY}` },
      body: JSON.stringify({ action, ...body }),
    });
    return res.json();
  };

  const startPolling = (id: string, amountUsd: number) => {
    if (pollRef.current) window.clearInterval(pollRef.current);
    pollRef.current = window.setInterval(async () => {
      const data = await callFapshi("status", { transId: id });
      const status = data?.status as string | undefined;
      if (status === "SUCCESSFUL") {
        if (pollRef.current) window.clearInterval(pollRef.current);
        // Credit wallet
        const newBalance = Number(currentBalance) + amountUsd;
        await supabase.from("wallets").update({ balance: newBalance }).eq("user_id", userId);
        await supabase.from("transactions").insert({
          user_id: userId,
          type: "topup",
          amount: amountUsd,
          description: `Top-up via ${method?.name}`,
          metadata: { provider: method?.id, transId: id, amountXaf: Math.round(amountUsd * USD_TO_XAF) },
        });
        setPendingStatus("success");
        await onSuccess();
        toast({ title: "Payment received", description: `$${amountUsd.toFixed(2)} added to your wallet.` });
      } else if (status === "FAILED" || status === "EXPIRED") {
        if (pollRef.current) window.clearInterval(pollRef.current);
        setPendingStatus(status === "EXPIRED" ? "expired" : "failed");
      }
    }, 5000);
  };

  const handleSubmit = async () => {
    if (!method) return;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt < method.minAmount) {
      toast({
        title: "Amount too low",
        description: `Minimum deposit for ${method.name} is $${method.minAmount}.`,
        variant: "destructive",
      });
      return;
    }

    setSubmitting(true);
    try {
      if (method.provider === "fapshi") {
        const amountXaf = Math.round(amt * USD_TO_XAF);
        const data = await callFapshi("initiate", {
          amountXaf,
          userId,
          externalId: `topup_${Date.now()}`,
          message: `Wallet top-up via ${method.name}`,
          redirectUrl: window.location.origin + "/dashboard",
        });
        if (!data?.link || !data?.transId) {
          throw new Error(data?.message || data?.error || "Failed to initiate payment");
        }
        setTransId(data.transId);
        setPaymentLink(data.link);
        setPendingStatus("waiting");
        setStep("pending");
        // Open payment page
        window.open(data.link, "_blank", "noopener,noreferrer");
        startPolling(data.transId, amt);
      } else {
        // Binance manual flow (placeholder until provider wired up)
        if (!reference.trim()) {
          toast({ title: "Reference required", description: "Enter your Binance Pay ID.", variant: "destructive" });
          setSubmitting(false);
          return;
        }
        const newBalance = Number(currentBalance) + amt;
        const { error: wErr } = await supabase.from("wallets").update({ balance: newBalance }).eq("user_id", userId);
        if (wErr) throw wErr;
        const { error: tErr } = await supabase.from("transactions").insert({
          user_id: userId,
          type: "topup",
          amount: amt,
          description: `Top-up via ${method.name}`,
          metadata: { provider: method.id, reference: reference.trim() },
        });
        if (tErr) throw tErr;
        toast({ title: "Top-up submitted", description: `$${amt.toFixed(2)} via ${method.name}.` });
        await onSuccess();
        handleClose(false);
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Failed to top up";
      toast({ title: "Error", description: message, variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  const amt = parseFloat(amount || "0");
  const xaf = Math.round((isNaN(amt) ? 0 : amt) * USD_TO_XAF);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="glass-strong border-border max-w-md p-0 overflow-hidden">
        {step === "method" && (
          <>
            <DialogHeader className="px-6 pt-6 pb-2 text-center">
              <p className="text-[10px] font-semibold tracking-[0.3em] text-muted-foreground uppercase">
                Social Amplifier
              </p>
              <DialogTitle className="font-display text-2xl sm:text-3xl mt-1">
                Accepted <span className="text-gradient-brand">Payment Methods</span>
              </DialogTitle>
              <DialogDescription className="text-xs mt-1">
                Choose how you want to top up your wallet.
              </DialogDescription>
            </DialogHeader>

            <div className="px-5 py-4 space-y-3">
              {METHODS.map((m) => (
                <button
                  key={m.id}
                  onClick={() => selectMethod(m)}
                  className="w-full glass border border-border/60 rounded-2xl p-4 flex items-center gap-3 sm:gap-4 hover:border-primary/50 hover:shadow-glow transition-all text-left group"
                >
                  <div
                    className={cn(
                      "h-14 w-14 sm:h-16 sm:w-16 rounded-2xl grid place-items-center shrink-0 ring-4",
                      m.iconBg,
                      m.iconRing
                    )}
                  >
                    <span className={cn("font-display font-bold text-base sm:text-lg leading-none", m.monogramColor)}>
                      {m.monogram}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="font-display font-bold text-base text-foreground leading-tight">{m.name}</p>
                    <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{m.description}</p>
                    <p className="text-[10px] uppercase tracking-wider text-primary-glow font-semibold mt-1.5">
                      Min ${m.minAmount}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "shrink-0 px-2.5 py-1 rounded-full text-[11px] font-semibold border",
                      m.category === "Mobile"
                        ? "bg-success/10 text-success border-success/30"
                        : "bg-warning/10 text-warning border-warning/30"
                    )}
                  >
                    {m.category}
                  </span>
                </button>
              ))}
            </div>

            <div className="px-6 pb-5 pt-1 flex items-center justify-center gap-1.5 text-[11px] text-muted-foreground">
              <ShieldCheck className="h-3 w-3 text-success" />
              Secure & encrypted • Funds credited after confirmation
            </div>
          </>
        )}

        {step === "details" && method && (
          <>
            <DialogHeader className="px-6 pt-6 pb-2">
              <button
                onClick={() => setStep("method")}
                className="absolute left-4 top-4 h-8 w-8 grid place-items-center rounded-lg border border-border bg-background/40 text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Back"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
              <div className="flex items-center gap-3 pt-1">
                <div className={cn("h-12 w-12 rounded-xl grid place-items-center shrink-0", method.iconBg)}>
                  <span className={cn("font-display font-bold text-sm", method.monogramColor)}>{method.monogram}</span>
                </div>
                <div>
                  <DialogTitle className="font-display text-lg">{method.name}</DialogTitle>
                  <DialogDescription className="text-xs">{method.description}</DialogDescription>
                </div>
              </div>
            </DialogHeader>

            <div className="px-6 py-4 space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label htmlFor="amount">Amount (USD)</Label>
                  <span className="text-[11px] text-muted-foreground">Min ${method.minAmount.toFixed(0)}</span>
                </div>
                <Input
                  id="amount"
                  type="number"
                  min={method.minAmount}
                  step="1"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="h-11 bg-background/40"
                />
                <div className="flex gap-2 pt-1">
                  {(method.id === "binance" ? [5, 10, 25, 50] : [3, 10, 25, 50]).map((v) => (
                    <Button
                      key={v}
                      type="button"
                      variant="outline"
                      size="sm"
                      className="flex-1"
                      onClick={() => setAmount(String(v))}
                    >
                      ${v}
                    </Button>
                  ))}
                </div>
                {method.provider === "fapshi" && (
                  <p className="text-[11px] text-muted-foreground pt-1">
                    You'll be charged{" "}
                    <span className="font-semibold text-foreground">{xaf.toLocaleString()} XAF</span> at $1 = {USD_TO_XAF} XAF.
                  </p>
                )}
              </div>

              {method.id === "binance" && (
                <div className="space-y-2">
                  <Label htmlFor="reference">Your Binance Pay ID</Label>
                  <div className="relative">
                    <Bitcoin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-warning" />
                    <Input
                      id="reference"
                      value={reference}
                      onChange={(e) => setReference(e.target.value)}
                      placeholder="e.g. 123456789"
                      className="pl-9 h-11 bg-background/40"
                    />
                  </div>
                </div>
              )}

              <div className="rounded-xl border border-dashed border-border/60 bg-card/30 p-3 text-[11px] text-muted-foreground flex items-start gap-2">
                <Sparkles className="h-3.5 w-3.5 text-primary-glow shrink-0 mt-0.5" />
                {method.provider === "fapshi" ? (
                  <p>
                    You'll be redirected to a secure {method.name} payment page. Enter your number there to complete the
                    payment — your wallet credits automatically once confirmed.
                  </p>
                ) : (
                  <p>
                    Binance Pay integration coming soon. This is a manual placeholder flow for now.
                  </p>
                )}
              </div>
            </div>

            <DialogFooter className="px-6 pb-6 pt-2">
              <Button variant="ghost" onClick={() => handleClose(false)} disabled={submitting}>
                Cancel
              </Button>
              <Button variant="hero" onClick={handleSubmit} disabled={submitting}>
                {submitting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : method.provider === "fapshi" ? (
                  `Pay ${xaf.toLocaleString()} XAF`
                ) : (
                  `Confirm $${amt.toFixed(2)}`
                )}
              </Button>
            </DialogFooter>
          </>
        )}

        {step === "pending" && method && (
          <>
            <DialogHeader className="px-6 pt-6 pb-2 text-center">
              <DialogTitle className="font-display text-xl">
                {pendingStatus === "success" ? "Payment received" : pendingStatus === "waiting" ? "Waiting for payment" : "Payment not completed"}
              </DialogTitle>
              <DialogDescription className="text-xs mt-1">
                {pendingStatus === "waiting" && "Complete the payment in the new tab. We'll credit your wallet automatically."}
                {pendingStatus === "success" && `$${amt.toFixed(2)} has been added to your balance.`}
                {pendingStatus === "failed" && "The payment failed. You can try again."}
                {pendingStatus === "expired" && "The payment session expired. Please try again."}
              </DialogDescription>
            </DialogHeader>

            <div className="px-6 py-6 grid place-items-center">
              {pendingStatus === "waiting" && <Loader2 className="h-10 w-10 animate-spin text-primary-glow" />}
              {pendingStatus === "success" && <CheckCircle2 className="h-12 w-12 text-success" />}
              {(pendingStatus === "failed" || pendingStatus === "expired") && (
                <div className="h-12 w-12 rounded-full bg-destructive/15 grid place-items-center text-destructive font-bold">!</div>
              )}
              {pendingStatus === "waiting" && paymentLink && (
                <a
                  href={paymentLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-4 text-xs text-primary-glow underline inline-flex items-center gap-1"
                >
                  Reopen payment page <ExternalLink className="h-3 w-3" />
                </a>
              )}
              {transId && (
                <p className="mt-3 text-[10px] text-muted-foreground font-mono">Ref: {transId}</p>
              )}
            </div>

            <DialogFooter className="px-6 pb-6 pt-2">
              {pendingStatus === "success" ? (
                <Button variant="hero" className="w-full" onClick={() => handleClose(false)}>
                  Done
                </Button>
              ) : pendingStatus === "waiting" ? (
                <Button variant="ghost" className="w-full" onClick={() => handleClose(false)}>
                  Close (we'll keep checking in the background)
                </Button>
              ) : (
                <>
                  <Button variant="ghost" onClick={() => handleClose(false)}>Cancel</Button>
                  <Button variant="hero" onClick={() => setStep("details")}>Try again</Button>
                </>
              )}
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
};
