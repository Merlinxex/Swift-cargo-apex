import { useEffect, useState } from "react";
import { CheckCircle2, X } from "lucide-react";
import { cn } from "@/lib/utils";

const fakePurchases = [
  { name: "Alex from London", item: "Instagram Growth Pack", time: "just now" },
  { name: "Priya from Mumbai", item: "Virtual OTP Numbers", time: "2 min ago" },
  { name: "Marco from Milan", item: "TikTok Views Boost", time: "4 min ago" },
  { name: "Yuki from Tokyo", item: "Pro Video Editing", time: "7 min ago" },
  { name: "Sara from Berlin", item: "Engagement Bot", time: "9 min ago" },
];

export const RecentPurchases = () => {
  const [index, setIndex] = useState(0);
  const [visible, setVisible] = useState(false);
  const [closed, setClosed] = useState(false);

  useEffect(() => {
    if (closed) return;
    const start = setTimeout(() => setVisible(true), 4000);
    return () => clearTimeout(start);
  }, [closed]);

  useEffect(() => {
    if (!visible || closed) return;
    const cycle = setInterval(() => {
      setVisible(false);
      setTimeout(() => {
        setIndex((p) => (p + 1) % fakePurchases.length);
        setVisible(true);
      }, 500);
    }, 7000);
    return () => clearInterval(cycle);
  }, [visible, closed]);

  if (closed) return null;
  const p = fakePurchases[index];

  return (
    <div
      className={cn(
        "fixed bottom-4 left-4 z-40 max-w-xs glass-strong rounded-2xl p-4 shadow-glow transition-all duration-500",
        visible ? "translate-y-0 opacity-100" : "translate-y-8 opacity-0 pointer-events-none"
      )}
    >
      <button
        onClick={() => setClosed(true)}
        className="absolute top-2 right-2 text-muted-foreground hover:text-foreground"
        aria-label="Close"
      >
        <X className="h-3.5 w-3.5" />
      </button>
      <div className="flex items-start gap-3">
        <div className="h-9 w-9 rounded-full bg-gradient-aurora grid place-items-center shrink-0 shadow-glow">
          <CheckCircle2 className="h-4 w-4 text-primary-foreground" />
        </div>
        <div className="min-w-0">
          <p className="text-sm font-medium text-foreground truncate">{p.name}</p>
          <p className="text-xs text-muted-foreground truncate">purchased <span className="text-primary-glow">{p.item}</span></p>
          <p className="text-[10px] text-muted-foreground mt-0.5">{p.time}</p>
        </div>
      </div>
    </div>
  );
};
