import { Link, useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Sparkles, LogOut, LayoutDashboard, Menu, X, Wallet } from "lucide-react";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";

export const Navbar = () => {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [balance, setBalance] = useState<number | null>(null);

  useEffect(() => {
    if (!user) {
      setBalance(null);
      return;
    }

    const loadBalance = async () => {
      const { data } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) setBalance(Number(data.balance));
    };

    void loadBalance();

    const channel = supabase
      .channel(`wallet-${user.id}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "wallets", filter: `user_id=eq.${user.id}` },
        (payload) => {
          const next = (payload.new as { balance?: number } | null)?.balance;
          if (typeof next === "number") setBalance(Number(next));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const links = [
    { href: "/calling", label: "Calling", internal: true },
    { href: "/boosting", label: "Boosting", internal: true },
    { href: "/editing", label: "Editing", internal: true },
    { href: "/verification", label: "Verification", internal: true },
    { href: "#how", label: "How it works" },
    { href: "/faq", label: "FAQ & Support", internal: true },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50">
      <div className="container mt-4">
        <div className="glass-strong rounded-2xl px-4 sm:px-6 py-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Link to="/" className="flex items-center gap-2 group shrink-0">
              <div className="relative h-8 w-8 rounded-lg bg-gradient-aurora grid place-items-center shadow-glow group-hover:shadow-glow-violet transition-all">
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-lg tracking-tight whitespace-nowrap">
                Social <span className="text-gradient-brand">Amplifier</span>
              </span>
            </Link>

            {user ? (
              <button
                onClick={() => navigate("/dashboard")}
                className="flex items-center gap-1.5 px-2.5 py-1 rounded-full border border-success/40 bg-success/10 text-success font-semibold text-xs sm:text-sm ml-1 hover:bg-success/20 transition-colors"
                aria-label="Open dashboard"
              >
                <Wallet className="h-3.5 w-3.5" />
                ${(balance ?? 0).toFixed(2)}
              </button>
            ) : (
              <Button
                variant="ghost"
                size="sm"
                className="md:hidden h-8 px-2.5 text-xs ml-1"
                onClick={() => navigate("/auth")}
              >
                Sign in
              </Button>
            )}
          </div>

          <nav className="hidden md:flex items-center gap-1">
            {links.map((l) => (
              l.internal ? (
                <Link
                  key={l.href}
                  to={l.href}
                  className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md"
                >
                  {l.label}
                </Link>
              ) : (
                <a
                  key={l.href}
                  href={l.href}
                  className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground transition-colors rounded-md"
                >
                  {l.label}
                </a>
              )
            ))}
          </nav>

          <div className="hidden md:flex items-center gap-2">
            {user ? (
              <>
                <Button variant="ghost" size="sm" onClick={() => navigate("/dashboard")}>
                  <LayoutDashboard className="h-4 w-4" /> Dashboard
                </Button>
                <Button variant="outline" size="sm" onClick={signOut}>
                  <LogOut className="h-4 w-4" /> Sign out
                </Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => navigate("/auth")}>Sign in</Button>
                <Button variant="hero" size="sm" onClick={() => navigate("/auth")}>Get started</Button>
              </>
            )}
          </div>

          <button
            className="md:hidden p-2 -mr-2 text-foreground shrink-0"
            onClick={() => setOpen(!open)}
            aria-label="Toggle menu"
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>

        <div
          className={cn(
            "md:hidden glass-strong rounded-2xl mt-2 overflow-hidden transition-all duration-300",
            open ? "max-h-96 opacity-100 p-4" : "max-h-0 opacity-0 p-0"
          )}
        >
          <nav className="flex flex-col gap-1">
            {links.map((l) => (
              l.internal ? (
                <Link key={l.href} to={l.href} onClick={() => setOpen(false)} className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground rounded-md">
                  {l.label}
                </Link>
              ) : (
                <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="px-3 py-2 text-sm text-muted-foreground hover:text-foreground rounded-md">
                  {l.label}
                </a>
              )
            ))}
            <div className="h-px bg-border my-2" />
            {user ? (
              <>
                <Button variant="ghost" size="sm" onClick={() => { setOpen(false); navigate("/dashboard"); }}>
                  Dashboard
                </Button>
                <Button variant="outline" size="sm" onClick={signOut}>Sign out</Button>
              </>
            ) : (
              <>
                <Button variant="ghost" size="sm" onClick={() => { setOpen(false); navigate("/auth"); }}>Sign in</Button>
                <Button variant="hero" size="sm" onClick={() => { setOpen(false); navigate("/auth"); }}>Get started</Button>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
};
