import { Zap, ShieldCheck, TrendingUp, Headphones } from "lucide-react";

const items = [
  { Icon: Zap, title: "Instant delivery", desc: "Most orders start within 60 seconds. Real-time order tracking included." },
  { Icon: ShieldCheck, title: "Secure checkout", desc: "PCI-compliant payments, encrypted data and zero-retention policy." },
  { Icon: TrendingUp, title: "Scalable solutions", desc: "From 1 to 1M units — bulk discounts and dedicated routing for power users." },
  { Icon: Headphones, title: "24/7 support", desc: "Real humans on chat and email. Average first-response under 4 minutes." },
];

export const Features = () => {
  return (
    <section className="py-20 sm:py-28">
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <p className="text-sm font-medium text-primary-glow mb-3 tracking-wider uppercase">Why us</p>
          <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
            Built for <span className="text-gradient-brand">speed, scale & safety</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {items.map((it, i) => (
            <div
              key={it.title}
              className="p-6 rounded-2xl glass hover:border-primary/50 transition-all duration-500 hover:shadow-glow group animate-fade-in-up"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <div className="h-12 w-12 rounded-xl bg-secondary border border-border grid place-items-center group-hover:bg-gradient-aurora group-hover:border-transparent transition-all duration-500">
                <it.Icon className="h-5 w-5 text-primary-glow group-hover:text-primary-foreground transition-colors" />
              </div>
              <h3 className="font-display font-semibold mt-5">{it.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{it.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
