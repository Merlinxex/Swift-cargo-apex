import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, ShieldCheck, Zap } from "lucide-react";
import { useNavigate } from "react-router-dom";
import heroOrbs from "@/assets/hero-orbs.jpg";

export const Hero = () => {
  const navigate = useNavigate();

  return (
    <section className="relative pt-36 pb-20 sm:pt-44 sm:pb-28 overflow-hidden">
      {/* Background layers */}
      <div className="absolute inset-0 grid-bg pointer-events-none" />
      <div className="absolute inset-0 bg-hero pointer-events-none" />

      <div className="container relative">
        <div className="max-w-4xl mx-auto text-center animate-fade-in-up">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full glass text-xs sm:text-sm text-muted-foreground mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-primary opacity-75" />
              <span className="relative inline-flex rounded-full h-2 w-2 bg-primary" />
            </span>
            Trusted by 120,000+ creators worldwide
          </div>

          <h1 className="font-display text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight leading-[1.05]">
            <span className="text-gradient">All-in-One Platform for</span>
            <br />
            <span className="text-gradient-brand">Digital Growth & Verification</span>
          </h1>

          <p className="mt-6 text-lg sm:text-xl text-muted-foreground max-w-2xl mx-auto">
            Fast. Secure. Scalable solutions for creators and businesses. Virtual numbers, social engagement, creative work and automation — all in one dashboard.
          </p>

          <div className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Button variant="hero" size="xl" onClick={() => navigate("/auth")}>
              Get Started <ArrowRight className="h-4 w-4" />
            </Button>
            <Button variant="glass" size="xl" asChild>
              <a href="#categories">Explore Services</a>
            </Button>
          </div>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-xs sm:text-sm text-muted-foreground">
            <span className="inline-flex items-center gap-2"><ShieldCheck className="h-4 w-4 text-success" /> Secure checkout</span>
            <span className="inline-flex items-center gap-2"><Zap className="h-4 w-4 text-warning" /> Instant delivery</span>
            <span className="inline-flex items-center gap-2"><Sparkles className="h-4 w-4 text-accent-violet" /> 24/7 support</span>
          </div>
        </div>

        {/* Hero visual */}
        <div className="mt-16 sm:mt-20 relative max-w-5xl mx-auto animate-fade-in-up [animation-delay:200ms]">
          <div className="absolute -inset-8 bg-aurora opacity-30 blur-3xl rounded-full" />
          <div className="relative rounded-3xl overflow-hidden border border-border shadow-elegant">
            <img
              src={heroOrbs}
              alt="Glowing neon orbs representing connected digital growth services"
              width={1600}
              height={1024}
              className="w-full h-auto"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
          </div>

          {/* Floating stats */}
          <div className="absolute -top-4 -left-4 sm:-top-6 sm:-left-6 glass-strong rounded-2xl px-4 py-3 shadow-glow animate-float hidden sm:block">
            <p className="text-xs text-muted-foreground">Orders delivered</p>
            <p className="font-display font-bold text-xl text-gradient-brand">2.4M+</p>
          </div>
          <div className="absolute -bottom-4 -right-4 sm:-bottom-6 sm:-right-6 glass-strong rounded-2xl px-4 py-3 shadow-glow-violet animate-float [animation-delay:1s] hidden sm:block">
            <p className="text-xs text-muted-foreground">Avg. delivery</p>
            <p className="font-display font-bold text-xl text-gradient-brand">{"< 60s"}</p>
          </div>
        </div>
      </div>
    </section>
  );
};
