import { MousePointerClick, CreditCard, Rocket } from "lucide-react";

const steps = [
  {
    Icon: MousePointerClick,
    title: "Choose a service",
    desc: "Pick from verification, social growth, creative or automation. Filter by speed and budget.",
  },
  {
    Icon: CreditCard,
    title: "Make payment",
    desc: "Pay with card, crypto or wallet. Encrypted checkout and instant invoice.",
  },
  {
    Icon: Rocket,
    title: "Receive delivery",
    desc: "Most services start in seconds. Track every order in real time from your dashboard.",
  },
];

export const HowItWorks = () => {
  return (
    <section id="how" className="py-20 sm:py-28 relative">
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <p className="text-sm font-medium text-primary-glow mb-3 tracking-wider uppercase">How it works</p>
          <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
            From order to delivery in <span className="text-gradient-brand">three steps</span>
          </h2>
        </div>

        <div className="relative grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Connector line */}
          <div className="hidden md:block absolute top-12 left-[16.6%] right-[16.6%] h-px bg-gradient-to-r from-transparent via-primary/40 to-transparent" />

          {steps.map((s, i) => (
            <div
              key={s.title}
              className="relative p-6 rounded-2xl glass text-center group animate-fade-in-up"
              style={{ animationDelay: `${i * 100}ms` }}
            >
              <div className="relative mx-auto h-16 w-16 rounded-2xl bg-gradient-aurora grid place-items-center shadow-glow group-hover:scale-110 transition-transform duration-500">
                <s.Icon className="h-6 w-6 text-primary-foreground" />
                <span className="absolute -top-2 -right-2 h-7 w-7 rounded-full bg-card border border-border text-xs font-display font-bold text-foreground grid place-items-center">
                  {i + 1}
                </span>
              </div>
              <h3 className="font-display font-semibold text-lg mt-6">{s.title}</h3>
              <p className="text-sm text-muted-foreground mt-2 leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
