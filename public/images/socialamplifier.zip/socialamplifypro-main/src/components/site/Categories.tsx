import { Link } from "react-router-dom";
import { PhoneCall, TrendingUp, Sparkles, type LucideIcon } from "lucide-react";

interface Cat {
  id: string;
  label: string;
  description: string;
  href: string;
  icon: LucideIcon;
  cta: string;
}

const cats: Cat[] = [
  {
    id: "calling",
    label: "Calling",
    description: "Virtual numbers, eSIMs and streaming accounts (Textplus, Nextplus, Google Voice, Netflix and more).",
    href: "/calling",
    icon: PhoneCall,
    cta: "Browse →",
  },
  {
    id: "boosting",
    label: "Boosting",
    description: "Real social engagement boosts: followers, likes, views and reach across Instagram, TikTok and YouTube.",
    href: "/boosting",
    icon: TrendingUp,
    cta: "Boost →",
  },
  {
    id: "editing",
    label: "Editing",
    description: "Pro photo edits, image-to-video, IDs and document edits delivered fast on WhatsApp.",
    href: "/editing",
    icon: Sparkles,
    cta: "Order →",
  },
];

export const Categories = () => {
  return (
    <section id="categories" className="py-20 sm:py-28">
      <div className="container">
        <div className="max-w-2xl mb-12 sm:mb-16">
          <p className="text-sm font-medium text-primary-glow mb-3 tracking-wider uppercase">Categories</p>
          <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
            Everything you need to <span className="text-gradient-brand">scale online</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {cats.map((cat, i) => {
            const Icon = cat.icon;
            return (
              <Link
                key={cat.id}
                to={cat.href}
                className="group relative p-6 rounded-2xl glass hover:border-primary/50 transition-all duration-500 hover:-translate-y-1 hover:shadow-glow animate-fade-in-up block"
                style={{ animationDelay: `${i * 80}ms` }}
              >
                <div className="absolute inset-0 rounded-2xl bg-gradient-aurora opacity-0 group-hover:opacity-10 transition-opacity duration-500 pointer-events-none" />
                <div className="relative">
                  <div className="h-12 w-12 rounded-xl bg-gradient-aurora grid place-items-center shadow-glow group-hover:scale-110 transition-transform duration-500">
                    <Icon className="h-5 w-5 text-primary-foreground" />
                  </div>
                  <h3 className="mt-5 font-display font-semibold text-lg">{cat.label}</h3>
                  <p className="mt-2 text-sm text-muted-foreground leading-relaxed">{cat.description}</p>
                  <div className="mt-4 inline-flex items-center text-xs font-medium text-primary-glow opacity-0 group-hover:opacity-100 transition-opacity">
                    {cat.cta}
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </div>
    </section>
  );
};
