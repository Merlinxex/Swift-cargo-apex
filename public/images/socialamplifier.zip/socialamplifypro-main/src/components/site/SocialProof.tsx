import { Star, Quote, ShieldCheck, Lock, Award, CheckCircle2 } from "lucide-react";

const stats = [
  { value: "120K+", label: "Active users" },
  { value: "2.4M", label: "Orders delivered" },
  { value: "99.98%", label: "Uptime SLA" },
  { value: "4.9/5", label: "Avg. rating" },
];

const testimonials = [
  {
    name: "Maya R.",
    role: "Content creator",
    quote: "Got my Instagram from 2k to 18k in 6 weeks. The drip-feed feels completely natural.",
  },
  {
    name: "Devon K.",
    role: "Indie SaaS founder",
    quote: "Their virtual numbers API saved our onboarding flow. Setup was 10 minutes flat.",
  },
  {
    name: "Hana T.",
    role: "Agency owner",
    quote: "We white-labeled the automation suite for 14 clients. Support is genuinely 24/7.",
  },
];

const trustBadges = [
  { Icon: ShieldCheck, label: "PCI DSS" },
  { Icon: Lock, label: "256-bit SSL" },
  { Icon: Award, label: "SOC 2 Ready" },
  { Icon: CheckCircle2, label: "GDPR" },
];

export const SocialProof = () => {
  return (
    <section id="trust" className="py-20 sm:py-28">
      <div className="container">
        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-20">
          {stats.map((s, i) => (
            <div
              key={s.label}
              className="p-6 rounded-2xl glass text-center animate-fade-in-up"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <p className="font-display font-bold text-3xl sm:text-4xl text-gradient-brand">{s.value}</p>
              <p className="mt-1 text-xs sm:text-sm text-muted-foreground">{s.label}</p>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="max-w-2xl mb-12">
          <p className="text-sm font-medium text-primary-glow mb-3 tracking-wider uppercase">Loved worldwide</p>
          <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
            Trusted by <span className="text-gradient-brand">creators & teams</span>
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="p-6 rounded-2xl glass relative animate-fade-in-up"
              style={{ animationDelay: `${i * 80}ms` }}
            >
              <Quote className="h-7 w-7 text-primary/40 absolute top-5 right-5" />
              <div className="flex items-center gap-1 mb-4">
                {Array.from({ length: 5 }).map((_, j) => (
                  <Star key={j} className="h-3.5 w-3.5 fill-warning text-warning" />
                ))}
              </div>
              <p className="text-sm text-foreground leading-relaxed">"{t.quote}"</p>
              <div className="mt-5 pt-5 border-t border-border/60">
                <p className="font-display font-semibold text-sm">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.role}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Trust badges */}
        <div className="mt-16 flex flex-wrap items-center justify-center gap-3">
          {trustBadges.map((b) => (
            <div key={b.label} className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass text-xs text-muted-foreground">
              <b.Icon className="h-3.5 w-3.5 text-success" /> {b.label}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
