import { Sparkles, Twitter, Github, Linkedin } from "lucide-react";
import { Link } from "react-router-dom";

export const Footer = () => {
  return (
    <footer className="border-t border-border/60 mt-32">
      <div className="container py-16">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2">
            <Link to="/" className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-lg bg-gradient-aurora grid place-items-center shadow-glow">
                <Sparkles className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-display font-bold text-lg">Social <span className="text-gradient-brand">Amplifier</span></span>
            </Link>
            <p className="mt-4 text-sm text-muted-foreground max-w-xs">
              The all-in-one platform for digital growth, verification, and creative services.
            </p>
            <div className="flex items-center gap-3 mt-6">
              {[Twitter, Github, Linkedin].map((Icon, i) => (
                <a key={i} href="#" className="h-9 w-9 rounded-lg glass grid place-items-center hover:border-primary/60 hover:shadow-glow transition-all">
                  <Icon className="h-4 w-4 text-muted-foreground" />
                </a>
              ))}
            </div>
          </div>

          {[
            { title: "Product", links: [
              { label: "Verification", href: "/verification" },
              { label: "Calling", href: "/calling" },
              { label: "Boosting", href: "/boosting" },
              { label: "Editing", href: "/editing" },
            ]},
            { title: "Company", links: [
              { label: "About", href: "#" },
              { label: "Blog", href: "#" },
              { label: "FAQ & Support", href: "/faq" },
              { label: "Contact", href: "#" },
            ]},
            { title: "Legal", links: [
              { label: "Terms", href: "#" },
              { label: "Privacy", href: "#" },
              { label: "Refunds", href: "#" },
              { label: "Acceptable Use", href: "#" },
            ]},
          ].map((col) => (
            <div key={col.title}>
              <h4 className="font-display font-semibold text-sm mb-4">{col.title}</h4>
              <ul className="space-y-2">
                {col.links.map((l) => (
                  <li key={l.label}>
                    {l.href.startsWith("/") ? (
                      <Link to={l.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{l.label}</Link>
                    ) : (
                      <a href={l.href} className="text-sm text-muted-foreground hover:text-foreground transition-colors">{l.label}</a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-12 pt-8 border-t border-border/60 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-xs text-muted-foreground">© {new Date().getFullYear()} Social Amplifier. All rights reserved.</p>
          <p className="text-xs text-muted-foreground">Built for creators and businesses worldwide.</p>
        </div>
      </div>
    </footer>
  );
};
