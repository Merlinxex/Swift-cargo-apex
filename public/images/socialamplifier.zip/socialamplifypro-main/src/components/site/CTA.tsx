import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles } from "lucide-react";
import { useNavigate } from "react-router-dom";

export const CTA = () => {
  const navigate = useNavigate();
  return (
    <section className="py-20 sm:py-28">
      <div className="container">
        <div className="relative overflow-hidden rounded-3xl glass-strong p-10 sm:p-16 text-center">
          <div className="absolute inset-0 bg-aurora opacity-20" />
          <div className="absolute -top-32 -right-32 h-64 w-64 rounded-full bg-primary/40 blur-3xl" />
          <div className="absolute -bottom-32 -left-32 h-64 w-64 rounded-full bg-accent-violet/40 blur-3xl" />

          <div className="relative max-w-2xl mx-auto">
            <Sparkles className="h-8 w-8 text-primary-glow mx-auto mb-4" />
            <h2 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
              Ready to <span className="text-gradient-brand">amplify</span> your reach?
            </h2>
            <p className="mt-4 text-muted-foreground text-lg">
              Join 120,000+ creators and teams using Social Amplifier to grow faster, smarter and safer.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Button variant="hero" size="xl" onClick={() => navigate("/auth")}>
                Create free account <ArrowRight className="h-4 w-4" />
              </Button>
              <Button variant="glass" size="xl" asChild>
                <a href="#services">Browse services</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
