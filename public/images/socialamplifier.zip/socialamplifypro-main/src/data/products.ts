// Product catalogs for Calling, Boosting and Editing pages.
// Prices are in USD and will be deducted from the user wallet on click.

export interface ShopProduct {
  id: string;
  name: string;
  description: string;
  price: number; // USD
  badge?: "Premium" | "New" | "Hot";
  icon: string; // lucide icon key
  tone: "blue" | "teal" | "amber" | "violet" | "green" | "red";
}

// Calling page — based on user reference image + Netflix
export const callingProducts: ShopProduct[] = [
  {
    id: "old-google-voice",
    name: "Old Google Voice",
    description: "Vintage US numbers from 2006–2020. Accepted on most Google products.",
    price: 8,
    icon: "PhoneCall",
    tone: "blue",
  },
  {
    id: "textplus-normal",
    name: "Textplus — Normal",
    description: "US virtual number, works for Gmail and standard SMS verification.",
    price: 5,
    icon: "MessageSquare",
    tone: "blue",
  },
  {
    id: "textplus-microsoft",
    name: "Textplus — Microsoft",
    description: "Dedicated for Microsoft / Outlook account verification.",
    price: 5,
    icon: "Mail",
    tone: "blue",
  },
  {
    id: "nextplus-normal",
    name: "Nextplus — Normal",
    description: "US virtual number for SMS verification. Great for everyday use.",
    price: 5,
    icon: "MessagesSquare",
    tone: "teal",
  },
  {
    id: "talku",
    name: "TalkU",
    description: "Paid calling & texting service. Real US number with voice support.",
    price: 6,
    icon: "Phone",
    tone: "violet",
  },
  {
    id: "dingtone",
    name: "Dingtone",
    description: "Voice & text number. Works across most verification platforms.",
    price: 6,
    icon: "Radio",
    tone: "teal",
  },
  {
    id: "netflix",
    name: "Netflix",
    description: "Premium Netflix account access for streaming worldwide.",
    price: 10,
    badge: "Hot",
    icon: "Film",
    tone: "red",
  },
  {
    id: "expressvpn",
    name: "ExpressVPN",
    description: "Premium VPN access to secure your connection and bypass geo-restrictions worldwide.",
    price: 2,
    badge: "New",
    icon: "Shield",
    tone: "green",
  },
];

// Editing page — from Premium Digital Services reference
export const editingProducts: ShopProduct[] = [
  // Individual Services
  {
    id: "pet-placement",
    name: "Pet Placement (Crate Scene)",
    description: "Realistic pet placed inside a travel crate scene.",
    price: 10,
    icon: "Image",
    tone: "blue",
  },
  {
    id: "veterinary-scene",
    name: "Veterinary Scene Edit",
    description: "Edited photo of a pet at a veterinary clinic.",
    price: 10,
    icon: "Image",
    tone: "teal",
  },
  {
    id: "veterinary-bill",
    name: "Veterinary Bill Creation",
    description: "Professional veterinary bill document creation.",
    price: 25,
    icon: "FileText",
    tone: "amber",
  },
  {
    id: "vehicle-transport",
    name: "Vehicle Transport Scene (Trailer)",
    description: "Edited photo of a vehicle loaded on a transport trailer.",
    price: 10,
    icon: "Image",
    tone: "violet",
  },
  {
    id: "custom-clearance",
    name: "Custom Clearance Scene (Vehicle)",
    description: "Edited photo of a vehicle cleared at customs.",
    price: 12,
    icon: "Image",
    tone: "blue",
  },
  {
    id: "advanced-visual",
    name: "Advanced Visual Edits",
    description: "Complex custom photo edits tailored to your request.",
    price: 10,
    badge: "Hot",
    icon: "Sparkles",
    tone: "violet",
  },
  {
    id: "image-to-video",
    name: "Image to Video Conversion",
    description: "Bring still images to life as short video clips.",
    price: 15,
    badge: "Hot",
    icon: "Video",
    tone: "red",
  },
  {
    id: "drivers-license",
    name: "Driver's License Design",
    description: "Professional driver's license design and edit.",
    price: 12,
    icon: "IdCard",
    tone: "teal",
  },
  {
    id: "ownership-transfer",
    name: "Ownership Transfer Documents",
    description: "Edited transfer of ownership documentation.",
    price: 25,
    badge: "Premium",
    icon: "FileCheck",
    tone: "amber",
  },
  {
    id: "refund-documentation",
    name: "Refund Documentation",
    description: "Professional refund documents edited to spec.",
    price: 35,
    badge: "Premium",
    icon: "FileText",
    tone: "amber",
  },
  {
    id: "document-editing",
    name: "Document Editing (All Types)",
    description: "Any document type edited professionally. Starting price.",
    price: 25,
    icon: "FileCheck",
    tone: "blue",
  },
  {
    id: "image-editing",
    name: "Image Editing (All Types)",
    description: "Any image editing request handled. Starting price.",
    price: 10,
    icon: "Image",
    tone: "teal",
  },

  // Packages
  {
    id: "package-starter",
    name: "Starter Package",
    description: "1 Scene / Edit · Standard Quality · 1 Revision · 2–3 Days Delivery.",
    price: 25,
    icon: "Package",
    tone: "blue",
  },
  {
    id: "package-growth",
    name: "Growth Package",
    description: "3 Scenes / Edits · High Quality · Up to 2 Revisions · Priority Support · 24–48H Delivery.",
    price: 60,
    badge: "Hot",
    icon: "TrendingUp",
    tone: "green",
  },
  {
    id: "package-elite",
    name: "Elite Package",
    description: "All-Inclusive Services · Premium Quality · Unlimited Revisions · VIP Priority · 12–24H Delivery.",
    price: 120,
    badge: "Premium",
    icon: "Crown",
    tone: "amber",
  },

  // Add-ons
  {
    id: "addon-express",
    name: "Express Delivery (24H)",
    description: "Rush turnaround — your edit moved to the front of the queue.",
    price: 10,
    icon: "Zap",
    tone: "red",
  },
  {
    id: "addon-vip",
    name: "VIP Priority Queue",
    description: "Dedicated handler, fastest delivery, direct WhatsApp updates.",
    price: 15,
    badge: "Premium",
    icon: "ShieldCheck",
    tone: "violet",
  },
  {
    id: "addon-revision",
    name: "Extra Revision",
    description: "One additional revision round after your edit is delivered.",
    price: 5,
    icon: "RefreshCw",
    tone: "blue",
  },
  {
    id: "addon-confidential",
    name: "Confidential Work",
    description: "Enhanced privacy handling — files deleted after delivery.",
    price: 10,
    icon: "Lock",
    tone: "violet",
  },
];

export const CALLING_WHATSAPP = "674449818";
export const EDITING_WHATSAPP = "654761173";
