export type ServiceCategory = "verification" | "social" | "editing";

export interface PricingTier {
  name: string;
  price: number;
  unit: string;
  features: string[];
}

export interface Service {
  id: string;
  name: string;
  category: ServiceCategory;
  tagline: string;
  description: string;
  delivery: string;
  startingAt: number;
  badge?: "Hot" | "New" | "Popular" | "Limited";
  tiers: PricingTier[];
  icon: string; // lucide icon name
}

export const categories: { id: ServiceCategory; label: string; description: string; icon: string }[] = [
  {
    id: "verification",
    label: "Verification Tools",
    description: "Virtual numbers for OTP & API access across 80+ countries.",
    icon: "ShieldCheck",
  },
  {
    id: "social",
    label: "Social Growth",
    description: "Real engagement boosts: followers, likes, views, comments.",
    icon: "TrendingUp",
  },
  {
    id: "editing",
    label: "Editing Services",
    description: "Video editing, thumbnails and design from pro creators.",
    icon: "Sparkles",
  },
];

export const services: Service[] = [
  {
    id: "virtual-numbers",
    name: "Virtual OTP Numbers",
    category: "verification",
    tagline: "Multi-country temporary numbers",
    description: "Receive SMS verifications instantly for WhatsApp, Telegram, Google, Discord and 200+ services. API access available.",
    delivery: "Instant",
    startingAt: 1.5,
    badge: "Hot",
    icon: "Smartphone",
    tiers: [
      { name: "Single", price: 1.5, unit: "per number", features: ["1 country", "Single use", "10 min window"] },
      { name: "Bulk 10", price: 12, unit: "pack of 10", features: ["Choose country", "Reuse 24h", "API access"] },
      { name: "API Pro", price: 49, unit: "monthly", features: ["80+ countries", "Unlimited rotation", "Priority routing"] },
    ],
  },
  {
    id: "instagram-growth",
    name: "Instagram Growth Pack",
    category: "social",
    tagline: "Real-looking followers + engagement",
    description: "Targeted follower delivery with engagement warmup. Drip-feed mode keeps growth natural and safe.",
    delivery: "0-2 hours",
    startingAt: 4.99,
    badge: "Popular",
    icon: "Instagram",
    tiers: [
      { name: "Starter", price: 4.99, unit: "1K followers", features: ["Drip feed", "Refill 30 days", "No password"] },
      { name: "Growth", price: 19, unit: "5K + likes", features: ["1K likes included", "Story views", "Refill 60 days"] },
      { name: "Viral", price: 79, unit: "25K bundle", features: ["Followers + likes + reach", "Reels boost", "Priority queue"] },
    ],
  },
  {
    id: "tiktok-views",
    name: "TikTok Views Boost",
    category: "social",
    tagline: "Push videos onto the FYP",
    description: "High-retention views that signal algorithm performance and trigger organic reach on the For You page.",
    delivery: "Instant",
    startingAt: 2,
    badge: "New",
    icon: "Music2",
    tiers: [
      { name: "Spark", price: 2, unit: "10K views", features: ["Instant start", "High retention"] },
      { name: "Trend", price: 8, unit: "50K views", features: ["+500 likes", "Geo targeting"] },
      { name: "Viral", price: 29, unit: "250K views", features: ["+ shares & saves", "FYP push"] },
    ],
  },
  {
    id: "youtube-likes",
    name: "YouTube Likes Package",
    category: "social",
    tagline: "Boost ranking signals",
    description: "Real-account likes delivered gradually to strengthen ranking signals without triggering platform flags.",
    delivery: "1-6 hours",
    startingAt: 3.5,
    icon: "Youtube",
    tiers: [
      { name: "Mini", price: 3.5, unit: "100 likes", features: ["Drip feed", "30d refill"] },
      { name: "Pro", price: 14, unit: "500 likes", features: ["+ watch time", "60d refill"] },
      { name: "Channel", price: 49, unit: "2.5K likes", features: ["Multi-video split", "Priority"] },
    ],
  },
  {
    id: "video-editing",
    name: "Pro Video Editing",
    category: "editing",
    tagline: "Short-form & long-form",
    description: "Cuts, captions, motion graphics, color grading. Delivered by editors who've shipped 10M+ views.",
    delivery: "24-72 hours",
    startingAt: 29,
    badge: "Limited",
    icon: "Video",
    tiers: [
      { name: "Basic", price: 29, unit: "per clip <60s", features: ["Cuts & captions", "1 revision", "48h delivery"] },
      { name: "Premium", price: 89, unit: "per clip", features: ["Motion graphics", "Color grade", "3 revisions"] },
      { name: "Bundle", price: 249, unit: "5 clips", features: ["Brand kit", "Thumbnails included", "Priority"] },
    ],
  },
  {
    id: "thumbnails",
    name: "Click-Magnet Thumbnails",
    category: "editing",
    tagline: "CTR-optimized designs",
    description: "Scroll-stopping thumbnails engineered with proven CTR patterns. Unlimited revisions until you love it.",
    delivery: "12-24 hours",
    startingAt: 12,
    icon: "Image",
    tiers: [
      { name: "Single", price: 12, unit: "1 thumbnail", features: ["2 concepts", "Unlimited revisions"] },
      { name: "Pack 5", price: 49, unit: "5 thumbnails", features: ["Style guide", "Source files"] },
      { name: "Monthly", price: 179, unit: "20 thumbnails", features: ["Same-day rush", "A/B variants"] },
    ],
  },
  {
    id: "photo-editing",
    name: "Photo Editing & Retouching",
    category: "editing",
    tagline: "Pro retouching & color",
    description: "Background removal, skin retouching, color grading and product photography polish for socials and stores.",
    delivery: "12-24 hours",
    startingAt: 8,
    badge: "New",
    icon: "Image",
    tiers: [
      { name: "Single", price: 8, unit: "1 photo", features: ["Background removal", "Color correction"] },
      { name: "Pack 10", price: 59, unit: "10 photos", features: ["Advanced retouch", "2 revisions each"] },
      { name: "Studio", price: 199, unit: "50 photos", features: ["Brand presets", "Same-day rush"] },
    ],
  },
  {
    id: "reels-editing",
    name: "Short-Form Reels Editing",
    category: "editing",
    tagline: "TikTok / Reels / Shorts",
    description: "Hook-driven cuts, captions, sound design and trending transitions optimized for retention and reach.",
    delivery: "24-48 hours",
    startingAt: 19,
    badge: "Hot",
    icon: "Video",
    tiers: [
      { name: "Single", price: 19, unit: "1 reel", features: ["Hook + captions", "1 revision"] },
      { name: "Pack 5", price: 79, unit: "5 reels", features: ["Sound design", "Trending effects"] },
      { name: "Monthly", price: 249, unit: "20 reels", features: ["Strategy call", "Priority queue"] },
    ],
  },
];
