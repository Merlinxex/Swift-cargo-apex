export interface Country {
  code: string;
  name: string;
  flag: string;
  price: number;
  available: number;
  popular?: boolean;
}

export interface VerificationApp {
  id: string;
  name: string;
  category: "social" | "messaging" | "finance" | "shopping" | "dating" | "other";
  basePrice: number;
  successRate: number;
  hot?: boolean;
  /** simpleicons.org slug for brand logo */
  logo?: string;
  /** brand color for logo background (hex without #) */
  brandColor?: string;
}

export const countries: Country[] = [
  { code: "US", name: "United States", flag: "🇺🇸", price: 1.5, available: 1284, popular: true },
  { code: "US-V", name: "United States (Virtual)", flag: "🇺🇸", price: 0.8, available: 2400, popular: true },
  { code: "GB", name: "United Kingdom", flag: "🇬🇧", price: 1.8, available: 642, popular: true },
  { code: "DE", name: "Germany", flag: "🇩🇪", price: 1.2, available: 891 },
  { code: "FR", name: "France", flag: "🇫🇷", price: 1.3, available: 512 },
  { code: "IN", name: "India", flag: "🇮🇳", price: 0.4, available: 3204, popular: true },
  { code: "BR", name: "Brazil", flag: "🇧🇷", price: 0.6, available: 1820 },
  { code: "ID", name: "Indonesia", flag: "🇮🇩", price: 0.5, available: 2104 },
  { code: "PH", name: "Philippines", flag: "🇵🇭", price: 0.7, available: 980 },
  { code: "RU", name: "Russia", flag: "🇷🇺", price: 0.9, available: 1502 },
  { code: "UA", name: "Ukraine", flag: "🇺🇦", price: 0.8, available: 720 },
  { code: "PL", name: "Poland", flag: "🇵🇱", price: 1.0, available: 612 },
  { code: "NL", name: "Netherlands", flag: "🇳🇱", price: 1.4, available: 410 },
  { code: "ES", name: "Spain", flag: "🇪🇸", price: 1.2, available: 522 },
  { code: "IT", name: "Italy", flag: "🇮🇹", price: 1.3, available: 480 },
  { code: "CA", name: "Canada", flag: "🇨🇦", price: 1.6, available: 720, popular: true },
  { code: "MX", name: "Mexico", flag: "🇲🇽", price: 0.7, available: 1402 },
  { code: "AR", name: "Argentina", flag: "🇦🇷", price: 0.6, available: 612 },
  { code: "AU", name: "Australia", flag: "🇦🇺", price: 1.7, available: 380 },
  { code: "JP", name: "Japan", flag: "🇯🇵", price: 2.1, available: 240 },
  { code: "KR", name: "South Korea", flag: "🇰🇷", price: 1.9, available: 320 },
  { code: "SG", name: "Singapore", flag: "🇸🇬", price: 1.8, available: 290 },
  { code: "TH", name: "Thailand", flag: "🇹🇭", price: 0.6, available: 1102 },
  { code: "VN", name: "Vietnam", flag: "🇻🇳", price: 0.5, available: 1504 },
  { code: "TR", name: "Turkey", flag: "🇹🇷", price: 0.8, available: 920 },
  { code: "EG", name: "Egypt", flag: "🇪🇬", price: 0.7, available: 612 },
  { code: "ZA", name: "South Africa", flag: "🇿🇦", price: 0.9, available: 410 },
  { code: "NG", name: "Nigeria", flag: "🇳🇬", price: 0.7, available: 820 },
  { code: "KE", name: "Kenya", flag: "🇰🇪", price: 0.6, available: 502 },
  { code: "AE", name: "UAE", flag: "🇦🇪", price: 1.5, available: 360 },
  { code: "SA", name: "Saudi Arabia", flag: "🇸🇦", price: 1.4, available: 412 },
  { code: "PK", name: "Pakistan", flag: "🇵🇰", price: 0.5, available: 1240 },
  { code: "BD", name: "Bangladesh", flag: "🇧🇩", price: 0.4, available: 1820 },
  { code: "MY", name: "Malaysia", flag: "🇲🇾", price: 0.9, available: 612 },
  { code: "SE", name: "Sweden", flag: "🇸🇪", price: 1.4, available: 320 },
  { code: "NO", name: "Norway", flag: "🇳🇴", price: 1.6, available: 240 },
  { code: "FI", name: "Finland", flag: "🇫🇮", price: 1.5, available: 210 },
  { code: "DK", name: "Denmark", flag: "🇩🇰", price: 1.5, available: 280 },
  { code: "BE", name: "Belgium", flag: "🇧🇪", price: 1.3, available: 320 },
  { code: "AT", name: "Austria", flag: "🇦🇹", price: 1.3, available: 280 },
  { code: "CH", name: "Switzerland", flag: "🇨🇭", price: 2.0, available: 180 },
  { code: "PT", name: "Portugal", flag: "🇵🇹", price: 1.1, available: 312 },
  { code: "IE", name: "Ireland", flag: "🇮🇪", price: 1.4, available: 220 },
  { code: "GR", name: "Greece", flag: "🇬🇷", price: 1.0, available: 380 },
  { code: "CZ", name: "Czechia", flag: "🇨🇿", price: 1.0, available: 410 },
  { code: "RO", name: "Romania", flag: "🇷🇴", price: 0.8, available: 612 },
  { code: "HU", name: "Hungary", flag: "🇭🇺", price: 0.9, available: 320 },
  { code: "IL", name: "Israel", flag: "🇮🇱", price: 1.5, available: 240 },
  { code: "CL", name: "Chile", flag: "🇨🇱", price: 0.8, available: 280 },
  { code: "CO", name: "Colombia", flag: "🇨🇴", price: 0.6, available: 720 },
  { code: "PE", name: "Peru", flag: "🇵🇪", price: 0.7, available: 410 },
  { code: "VE", name: "Venezuela", flag: "🇻🇪", price: 0.5, available: 380 },
  { code: "HK", name: "Hong Kong", flag: "🇭🇰", price: 1.7, available: 220 },
  { code: "TW", name: "Taiwan", flag: "🇹🇼", price: 1.5, available: 320 },
  { code: "NZ", name: "New Zealand", flag: "🇳🇿", price: 1.6, available: 180 },
];

export const apps: VerificationApp[] = [
  { id: "whatsapp", name: "WhatsApp", category: "messaging", basePrice: 1.2, successRate: 98, hot: true, logo: "whatsapp", brandColor: "25D366" },
  { id: "telegram", name: "Telegram", category: "messaging", basePrice: 1.0, successRate: 99, hot: true, logo: "telegram", brandColor: "26A5E4" },
  { id: "google", name: "Google", category: "social", basePrice: 1.5, successRate: 96, hot: true, logo: "google", brandColor: "4285F4" },
  { id: "discord", name: "Discord", category: "social", basePrice: 1.1, successRate: 97, logo: "discord", brandColor: "5865F2" },
  { id: "instagram", name: "Instagram", category: "social", basePrice: 1.3, successRate: 95, hot: true, logo: "instagram", brandColor: "E4405F" },
  { id: "facebook", name: "Facebook", category: "social", basePrice: 1.2, successRate: 94, logo: "facebook", brandColor: "1877F2" },
  { id: "tiktok", name: "TikTok", category: "social", basePrice: 1.4, successRate: 93, hot: true, logo: "tiktok", brandColor: "000000" },
  { id: "twitter", name: "X (Twitter)", category: "social", basePrice: 1.3, successRate: 95, logo: "x", brandColor: "000000" },
  { id: "snapchat", name: "Snapchat", category: "social", basePrice: 1.2, successRate: 94, logo: "snapchat", brandColor: "FFFC00" },
  { id: "linkedin", name: "LinkedIn", category: "social", basePrice: 1.5, successRate: 96, logo: "linkedin", brandColor: "0A66C2" },
  { id: "reddit", name: "Reddit", category: "social", basePrice: 1.0, successRate: 97, logo: "reddit", brandColor: "FF4500" },
  { id: "signal", name: "Signal", category: "messaging", basePrice: 1.2, successRate: 96, logo: "signal", brandColor: "3A76F0" },
  { id: "viber", name: "Viber", category: "messaging", basePrice: 1.1, successRate: 95, logo: "viber", brandColor: "7360F2" },
  { id: "wechat", name: "WeChat", category: "messaging", basePrice: 1.6, successRate: 90, logo: "wechat", brandColor: "07C160" },
  { id: "line", name: "LINE", category: "messaging", basePrice: 1.4, successRate: 92, logo: "line", brandColor: "00C300" },
  { id: "uber", name: "Uber", category: "other", basePrice: 1.5, successRate: 95, logo: "uber", brandColor: "000000" },
  { id: "lyft", name: "Lyft", category: "other", basePrice: 1.5, successRate: 94, logo: "lyft", brandColor: "FF00BF" },
  { id: "doordash", name: "DoorDash", category: "shopping", basePrice: 1.4, successRate: 93, logo: "doordash", brandColor: "FF3008" },
  { id: "amazon", name: "Amazon", category: "shopping", basePrice: 1.6, successRate: 92, logo: "amazon", brandColor: "FF9900" },
  { id: "ebay", name: "eBay", category: "shopping", basePrice: 1.4, successRate: 94, logo: "ebay", brandColor: "E53238" },
  { id: "paypal", name: "PayPal", category: "finance", basePrice: 2.0, successRate: 88, logo: "paypal", brandColor: "003087" },
  { id: "venmo", name: "Venmo", category: "finance", basePrice: 1.9, successRate: 89, logo: "venmo", brandColor: "008CFF" },
  { id: "cashapp", name: "Cash App", category: "finance", basePrice: 1.8, successRate: 90, logo: "cashapp", brandColor: "00C244" },
  { id: "revolut", name: "Revolut", category: "finance", basePrice: 1.9, successRate: 89, logo: "revolut", brandColor: "0075EB" },
  { id: "tinder", name: "Tinder", category: "dating", basePrice: 1.5, successRate: 93, logo: "tinder", brandColor: "FF6B6B" },
  { id: "bumble", name: "Bumble", category: "dating", basePrice: 1.5, successRate: 92, logo: "bumble", brandColor: "FFC629" },
  { id: "hinge", name: "Hinge", category: "dating", basePrice: 1.5, successRate: 91, logo: "hinge", brandColor: "000000" },
  { id: "openai", name: "OpenAI / ChatGPT", category: "other", basePrice: 1.7, successRate: 94, hot: true, logo: "openai", brandColor: "412991" },
  { id: "claude", name: "Claude", category: "other", basePrice: 1.7, successRate: 95, logo: "anthropic", brandColor: "D97706" },
  { id: "spotify", name: "Spotify", category: "other", basePrice: 1.2, successRate: 96, logo: "spotify", brandColor: "1DB954" },
  { id: "netflix", name: "Netflix", category: "other", basePrice: 1.4, successRate: 94, logo: "netflix", brandColor: "E50914" },
  { id: "twitch", name: "Twitch", category: "social", basePrice: 1.2, successRate: 95, logo: "twitch", brandColor: "9146FF" },
];

export const appCategories = [
  { id: "messaging", label: "Messaging" },
  { id: "social", label: "Social" },
  { id: "finance", label: "Finance" },
  { id: "shopping", label: "Shopping" },
  { id: "dating", label: "Dating" },
  { id: "other", label: "Other" },
] as const;
