import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Sparkles, LogOut, Wallet, CheckCircle2, Clock, RotateCcw, Plus,
  Loader2, Phone, Shield, Menu,
} from "lucide-react";
import { TopUpDialog } from "@/components/dashboard/TopUpDialog";

interface WalletRow {
  balance: number;
  total_spent: number;
  total_refunded: number;
}

interface Activation {
  id: string;
  service: string;
  country: string;
  phone_number: string;
  price: number;
  status: string;
  otp_code: string | null;
  created_at: string;
}

interface Tx {
  id: string;
  type: string;
  amount: number;
  description: string | null;
  created_at: string;
}

const Dashboard = () => {
  const { user, loading, signOut } = useAuth();
  const navigate = useNavigate();


  const [wallet, setWallet] = useState<WalletRow | null>(null);
  const [activations, setActivations] = useState<Activation[]>([]);
  const [transactions, setTransactions] = useState<Tx[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [topUpOpen, setTopUpOpen] = useState(false);
  const [dataLoading, setDataLoading] = useState(true);

  useEffect(() => {
    document.title = "Dashboard • Social Amplifier";
  }, []);

  useEffect(() => {
    if (!loading && !user) navigate("/auth", { replace: true });
  }, [user, loading, navigate]);

  const loadData = useCallback(async () => {
    if (!user) return;
    setDataLoading(true);
    const [w, a, t, r] = await Promise.all([
      supabase.from("wallets").select("balance,total_spent,total_refunded").eq("user_id", user.id).maybeSingle(),
      supabase.from("activations").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
      supabase.from("transactions").select("*").eq("user_id", user.id).order("created_at", { ascending: false }).limit(20),
      supabase.from("user_roles").select("role").eq("user_id", user.id).eq("role", "admin").maybeSingle(),
    ]);
    if (w.data) setWallet(w.data as WalletRow);
    else setWallet({ balance: 0, total_spent: 0, total_refunded: 0 });
    if (a.data) setActivations(a.data as Activation[]);
    if (t.data) setTransactions(t.data as Tx[]);
    setIsAdmin(!!r.data);
    setDataLoading(false);
  }, [user]);

  useEffect(() => { void loadData(); }, [loadData]);

  if (loading || !user) {
    return (
      <main className="min-h-screen grid place-items-center">
        <Loader2 className="h-6 w-6 animate-spin text-primary-glow" />
      </main>
    );
  }

  const balance = Number(wallet?.balance ?? 0);
  const totalRefunded = Number(wallet?.total_refunded ?? 0);
  const activeNumbers = activations.filter(a => a.status === "waiting").length;
  const totalActivations = activations.filter(a => a.status === "received").length;

  const stats = [
    { Icon: Wallet, label: "Available Balance", value: `$${balance.toFixed(2)}`, color: "text-primary-glow", bg: "bg-primary/15" },
    { Icon: CheckCircle2, label: "Total Activations", value: totalActivations.toString(), color: "text-success", bg: "bg-success/15" },
    { Icon: Clock, label: "Active Numbers", value: activeNumbers.toString(), color: "text-warning", bg: "bg-warning/15" },
    { Icon: RotateCcw, label: "Total Refunded", value: `$${totalRefunded.toFixed(2)}`, color: "text-accent-violet", bg: "bg-accent-violet/15" },
  ];

  return (
    <main className="min-h-screen relative">
      <div className="absolute inset-0 grid-bg pointer-events-none opacity-50" />

      {/* Header */}
      <header className="relative border-b border-border/60 glass-strong sticky top-0 z-30">
        <div className="container py-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Button variant="outline" size="icon" className="h-9 w-9 shrink-0" onClick={() => navigate("/")}>
              <Menu className="h-4 w-4" />
            </Button>
            <h1 className="font-display font-bold text-lg sm:text-xl truncate">Dashboard</h1>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <div className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-full border border-success/40 bg-success/10 text-success font-semibold text-sm">
              <Wallet className="h-3.5 w-3.5" />
              ${balance.toFixed(2)}
            </div>
            <Button variant="glow" size="sm" className="font-semibold" onClick={() => setTopUpOpen(true)}>
              <Plus className="h-4 w-4" /> Top Up
            </Button>
            {isAdmin && (
              <Button variant="outline" size="icon" className="h-9 w-9" onClick={() => navigate("/admin")} title="Admin">
                <Shield className="h-4 w-4 text-primary-glow" />
              </Button>
            )}
            <Button variant="outline" size="icon" className="h-9 w-9" onClick={async () => { await signOut(); navigate("/"); }} title="Sign out">
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <div className="relative container py-6">
        {/* Stat cards */}
        <div className="grid grid-cols-2 gap-3 sm:gap-4 mb-6">
          {stats.map((s) => (
            <Card key={s.label} className="glass border-border p-4 sm:p-5 rounded-2xl">
              <div className={`h-11 w-11 rounded-xl ${s.bg} grid place-items-center mb-3`}>
                <s.Icon className={`h-5 w-5 ${s.color}`} />
              </div>
              <p className="font-display font-bold text-2xl sm:text-3xl">{s.value}</p>
              <p className="text-xs sm:text-sm text-muted-foreground mt-1">{s.label}</p>
            </Card>
          ))}
        </div>

        {/* Quick action */}
        <Card className="glass border-border rounded-2xl p-5 mb-6">
          <div className="flex items-center justify-between gap-3">
            <div className="min-w-0">
              <h2 className="font-display font-semibold text-base">Rent a virtual number</h2>
              <p className="text-xs text-muted-foreground mt-0.5">Browse 50+ countries and 200+ services.</p>
            </div>
            <Button variant="hero" size="sm" onClick={() => navigate("/verification")}>
              <Phone className="h-4 w-4" /> Browse
            </Button>
          </div>
        </Card>

        {/* Recent activations */}
        <Card className="glass border-border rounded-2xl overflow-hidden mb-6">
          <div className="p-4 sm:p-5 border-b border-border/60 flex items-center justify-between">
            <h2 className="font-display font-semibold">Recent Activations</h2>
            <span className="text-xs text-muted-foreground">{activations.length} total</span>
          </div>
          {dataLoading ? (
            <div className="p-8 grid place-items-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
          ) : activations.length === 0 ? (
            <div className="p-8 text-center">
              <Phone className="h-10 w-10 mx-auto text-muted-foreground mb-2 opacity-40" />
              <p className="text-sm text-muted-foreground">No activations yet</p>
              <Button variant="link" size="sm" onClick={() => navigate("/verification")}>Rent your first number →</Button>
            </div>
          ) : (
            <div className="divide-y divide-border/60">
              {activations.map((a) => (
                <div key={a.id} className="p-4 flex items-center justify-between gap-3">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium text-sm truncate">{a.service}</p>
                    <p className="text-xs text-muted-foreground font-mono mt-0.5">{a.phone_number} · {a.country}</p>
                    {a.otp_code && (
                      <p className="text-xs mt-1 font-mono text-success">Code: {a.otp_code}</p>
                    )}
                  </div>
                  <div className="text-right shrink-0">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold border uppercase tracking-wider ${
                      a.status === "received" ? "bg-success/15 text-success border-success/30" :
                      a.status === "waiting" ? "bg-warning/15 text-warning border-warning/30" :
                      "bg-muted text-muted-foreground border-border"
                    }`}>{a.status}</span>
                    <p className="text-sm font-semibold mt-1">${Number(a.price).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        {/* Recent transactions */}
        <Card className="glass border-border rounded-2xl overflow-hidden">
          <div className="p-4 sm:p-5 border-b border-border/60">
            <h2 className="font-display font-semibold">Recent Transactions</h2>
          </div>
          {transactions.length === 0 ? (
            <div className="p-8 text-center text-sm text-muted-foreground">No transactions yet</div>
          ) : (
            <div className="divide-y divide-border/60">
              {transactions.map((t) => (
                <div key={t.id} className="p-4 flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium capitalize">{t.description || t.type}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{new Date(t.created_at).toLocaleString()}</p>
                  </div>
                  <p className={`font-display font-bold ${t.type === "topup" || t.type === "refund" ? "text-success" : "text-foreground"}`}>
                    {t.type === "charge" ? "-" : "+"}${Number(t.amount).toFixed(2)}
                  </p>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <TopUpDialog
        open={topUpOpen}
        onOpenChange={setTopUpOpen}
        userId={user.id}
        currentBalance={balance}
        onSuccess={loadData}
      />
    </main>
  );
};

export default Dashboard;
