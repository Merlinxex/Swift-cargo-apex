import { useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Shield, Users, Wallet, Phone, Loader2, ArrowLeft, Search,
  ShieldOff, ShieldCheck, Edit3, Sparkles,
} from "lucide-react";
import { EDITING_WHATSAPP } from "@/data/products";
import { useToast } from "@/hooks/use-toast";

interface UserRow {
  id: string;
  display_name: string | null;
  created_at: string;
  balance: number;
  total_spent: number;
  total_refunded: number;
  is_admin: boolean;
  is_primary?: boolean;
}

const PRIMARY_ADMIN_NAME_HINT = "ndzeydzerooney";

interface AdminActivation {
  id: string;
  user_id: string;
  service: string;
  country: string;
  phone_number: string;
  price: number;
  status: string;
  created_at: string;
}

interface EditingOrder {
  id: string;
  user_id: string;
  amount: number;
  description: string | null;
  created_at: string;
  metadata: { product_id?: string; product_name?: string; whatsapp?: string } | null;
  display_name?: string | null;
}

const Admin = () => {
  const { user, loading: authLoading } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();

  const [checkingAdmin, setCheckingAdmin] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);
  const [users, setUsers] = useState<UserRow[]>([]);
  const [activations, setActivations] = useState<AdminActivation[]>([]);
  const [editingOrders, setEditingOrders] = useState<EditingOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [editUser, setEditUser] = useState<UserRow | null>(null);
  const [editBalance, setEditBalance] = useState("0");
  const [saving, setSaving] = useState(false);

  useEffect(() => { document.title = "Admin • Social Amplifier"; }, []);

  useEffect(() => {
    if (authLoading) return;
    if (!user) { navigate("/auth", { replace: true }); return; }
    (async () => {
      const { data } = await supabase
        .from("user_roles")
        .select("role")
        .eq("user_id", user.id)
        .eq("role", "admin")
        .maybeSingle();
      setIsAdmin(!!data);
      setCheckingAdmin(false);
    })();
  }, [user, authLoading, navigate]);

  const loadData = useCallback(async () => {
    setLoading(true);
    const [profilesRes, walletsRes, rolesRes, actsRes, txRes] = await Promise.all([
      supabase.from("profiles").select("id,display_name,created_at"),
      supabase.from("wallets").select("user_id,balance,total_spent,total_refunded"),
      supabase.from("user_roles").select("user_id,role").eq("role", "admin"),
      supabase.from("activations").select("*").order("created_at", { ascending: false }).limit(50),
      supabase.from("transactions")
        .select("id,user_id,amount,description,created_at,metadata")
        .eq("type", "charge")
        .order("created_at", { ascending: false })
        .limit(200),
    ]);

    const wMap = new Map<string, { balance: number; total_spent: number; total_refunded: number }>();
    (walletsRes.data ?? []).forEach((w) => wMap.set(w.user_id, {
      balance: Number(w.balance), total_spent: Number(w.total_spent), total_refunded: Number(w.total_refunded),
    }));
    const adminSet = new Set((rolesRes.data ?? []).map((r) => r.user_id));

    const nameMap = new Map<string, string | null>();
    (profilesRes.data ?? []).forEach((p) => nameMap.set(p.id, p.display_name));

    const merged: UserRow[] = (profilesRes.data ?? []).map((p) => ({
      id: p.id,
      display_name: p.display_name,
      created_at: p.created_at,
      balance: wMap.get(p.id)?.balance ?? 0,
      total_spent: wMap.get(p.id)?.total_spent ?? 0,
      total_refunded: wMap.get(p.id)?.total_refunded ?? 0,
      is_admin: adminSet.has(p.id),
      is_primary: (p.display_name ?? "").toLowerCase().includes(PRIMARY_ADMIN_NAME_HINT),
    }));

    const editingOnly: EditingOrder[] = ((txRes.data ?? []) as EditingOrder[])
      .filter((t) => t.metadata?.whatsapp === EDITING_WHATSAPP)
      .map((t) => ({ ...t, display_name: nameMap.get(t.user_id) ?? null }));

    setUsers(merged);
    setActivations((actsRes.data ?? []) as AdminActivation[]);
    setEditingOrders(editingOnly);
    setLoading(false);
  }, []);

  useEffect(() => { if (isAdmin) void loadData(); }, [isAdmin, loadData]);

  const toggleAdmin = async (u: UserRow) => {
    try {
      if (u.is_admin) {
        const { error } = await supabase.from("user_roles").delete().eq("user_id", u.id).eq("role", "admin");
        if (error) throw error;
        toast({ title: "Admin removed", description: u.display_name ?? u.id });
      } else {
        const { error } = await supabase.from("user_roles").insert({ user_id: u.id, role: "admin" });
        if (error) throw error;
        toast({ title: "Admin granted", description: u.display_name ?? u.id });
      }
      await loadData();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Failed to update role";
      toast({ title: "Error", description: message, variant: "destructive" });
    }
  };

  const openEdit = (u: UserRow) => {
    setEditUser(u);
    setEditBalance(u.balance.toString());
  };

  const saveBalance = async () => {
    if (!editUser) return;
    const newBal = parseFloat(editBalance);
    if (isNaN(newBal) || newBal < 0) {
      toast({ title: "Invalid amount", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const delta = newBal - editUser.balance;
      const { error: wErr } = await supabase.from("wallets").update({ balance: newBal }).eq("user_id", editUser.id);
      if (wErr) throw wErr;
      if (delta !== 0) {
        await supabase.from("transactions").insert({
          user_id: editUser.id,
          type: delta > 0 ? "topup" : "charge",
          amount: Math.abs(delta),
          description: "Admin adjustment",
        });
      }
      toast({ title: "Balance updated", description: `Set to $${newBal.toFixed(2)}` });
      setEditUser(null);
      await loadData();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : "Failed to update balance";
      toast({ title: "Error", description: message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  if (authLoading || checkingAdmin) {
    return <main className="min-h-screen grid place-items-center"><Loader2 className="h-6 w-6 animate-spin text-primary-glow" /></main>;
  }

  if (!isAdmin) {
    return (
      <main className="min-h-screen grid place-items-center px-4">
        <Card className="glass-strong border-border p-8 max-w-md text-center rounded-2xl">
          <ShieldOff className="h-12 w-12 mx-auto text-destructive mb-3" />
          <h1 className="font-display text-2xl font-bold mb-2">Access denied</h1>
          <p className="text-sm text-muted-foreground mb-5">You don't have permission to view the admin panel.</p>
          <Button variant="hero" onClick={() => navigate("/dashboard")}>Back to dashboard</Button>
        </Card>
      </main>
    );
  }

  const filtered = users.filter((u) =>
    !search ||
    (u.display_name ?? "").toLowerCase().includes(search.toLowerCase()) ||
    u.id.includes(search)
  );

  const totalBalance = users.reduce((s, u) => s + u.balance, 0);
  const totalSpent = users.reduce((s, u) => s + u.total_spent, 0);
  const stats = [
    { Icon: Users, label: "Total users", value: users.length.toString() },
    { Icon: ShieldCheck, label: "Admins", value: users.filter(u => u.is_admin).length.toString() },
    { Icon: Wallet, label: "Total balance", value: `$${totalBalance.toFixed(2)}` },
    { Icon: Phone, label: "Activations", value: activations.length.toString() },
  ];

  return (
    <main className="min-h-screen relative">
      <div className="absolute inset-0 grid-bg pointer-events-none opacity-40" />

      <header className="relative border-b border-border/60 glass-strong sticky top-0 z-30">
        <div className="container py-3 flex items-center justify-between gap-2">
          <div className="flex items-center gap-2 min-w-0">
            <Button variant="outline" size="icon" className="h-9 w-9" onClick={() => navigate("/dashboard")}>
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <Shield className="h-5 w-5 text-primary-glow shrink-0" />
            <h1 className="font-display font-bold text-lg sm:text-xl truncate">Admin Panel</h1>
          </div>
          <span className="hidden sm:block text-xs text-muted-foreground">Total spent: ${totalSpent.toFixed(2)}</span>
        </div>
      </header>

      <div className="relative container py-6">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 mb-6">
          {stats.map((s) => (
            <Card key={s.label} className="glass border-border p-4 rounded-2xl">
              <s.Icon className="h-5 w-5 text-primary-glow mb-2" />
              <p className="font-display font-bold text-2xl">{s.value}</p>
              <p className="text-xs text-muted-foreground mt-0.5">{s.label}</p>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="users">
          <TabsList className="mb-4">
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="activations">Activations</TabsTrigger>
            <TabsTrigger value="editing">Editing Orders</TabsTrigger>
          </TabsList>

          <TabsContent value="users">
            <Card className="glass border-border rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-border/60 flex items-center gap-2">
                <Search className="h-4 w-4 text-muted-foreground shrink-0" />
                <Input placeholder="Search by name or ID…" value={search} onChange={(e) => setSearch(e.target.value)} className="bg-background/40 border-0 h-9" />
              </div>
              {loading ? (
                <div className="p-8 grid place-items-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
              ) : (
                <div className="divide-y divide-border/60">
                  {filtered.map((u) => (
                    <div key={u.id} className="p-4 flex items-center justify-between gap-3 flex-wrap">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="font-medium text-sm truncate">{u.display_name ?? "Unnamed"}</p>
                          {u.is_admin && <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-primary/20 text-primary-glow border border-primary/30">Admin</span>}
                          {u.is_primary && <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase bg-warning/20 text-warning border border-warning/30">Primary</span>}
                        </div>
                        <p className="text-[11px] text-muted-foreground font-mono truncate">{u.id}</p>
                        <div className="flex gap-3 mt-1.5 text-xs">
                          <span className="text-success">${u.balance.toFixed(2)}</span>
                          <span className="text-muted-foreground">spent ${u.total_spent.toFixed(2)}</span>
                        </div>
                      </div>
                      <div className="flex gap-1.5 shrink-0">
                        <Button size="sm" variant="outline" onClick={() => openEdit(u)} title="Edit balance">
                          <Edit3 className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm"
                          variant={u.is_admin ? "outline" : "glow"}
                          onClick={() => toggleAdmin(u)}
                          disabled={u.is_primary && u.is_admin}
                          title={u.is_primary && u.is_admin ? "Primary admin cannot be revoked" : undefined}
                        >
                          {u.is_admin ? <><ShieldOff className="h-3.5 w-3.5" /> Revoke</> : <><ShieldCheck className="h-3.5 w-3.5" /> Promote</>}
                        </Button>
                      </div>
                    </div>
                  ))}
                  {filtered.length === 0 && (
                    <div className="p-8 text-center text-sm text-muted-foreground">No users match.</div>
                  )}
                </div>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="activations">
            <Card className="glass border-border rounded-2xl overflow-hidden">
              {loading ? (
                <div className="p-8 grid place-items-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
              ) : activations.length === 0 ? (
                <div className="p-8 text-center text-sm text-muted-foreground">No activations yet.</div>
              ) : (
                <div className="divide-y divide-border/60">
                  {activations.map((a) => (
                    <div key={a.id} className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-sm truncate">{a.service} · {a.country}</p>
                        <p className="text-xs text-muted-foreground font-mono mt-0.5">{a.phone_number}</p>
                        <p className="text-[11px] text-muted-foreground font-mono mt-0.5">user: {a.user_id.slice(0, 8)}…</p>
                      </div>
                      <div className="text-right shrink-0">
                        <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold border uppercase ${
                          a.status === "received" ? "bg-success/15 text-success border-success/30" :
                          a.status === "waiting" ? "bg-warning/15 text-warning border-warning/30" :
                          "bg-muted text-muted-foreground border-border"
                        }`}>{a.status}</span>
                        <p className="text-sm font-semibold mt-1">${Number(a.price).toFixed(2)}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </TabsContent>

          <TabsContent value="editing">
            <Card className="glass border-border rounded-2xl overflow-hidden">
              <div className="p-4 border-b border-border/60 flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-primary-glow" />
                  <p className="text-sm font-medium">Editing service orders</p>
                </div>
                <span className="text-xs text-muted-foreground">
                  {editingOrders.length} order{editingOrders.length === 1 ? "" : "s"} · $
                  {editingOrders.reduce((s, o) => s + Math.abs(Number(o.amount)), 0).toFixed(2)}
                </span>
              </div>
              {loading ? (
                <div className="p-8 grid place-items-center"><Loader2 className="h-5 w-5 animate-spin text-muted-foreground" /></div>
              ) : editingOrders.length === 0 ? (
                <div className="p-8 text-center text-sm text-muted-foreground">No editing orders yet.</div>
              ) : (
                <div className="divide-y divide-border/60">
                  {editingOrders.map((o) => (
                    <div key={o.id} className="p-4 flex items-center justify-between gap-3">
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-sm truncate">
                          {o.metadata?.product_name ?? o.description ?? "Editing order"}
                        </p>
                        <p className="text-[11px] text-muted-foreground truncate mt-0.5">
                          {o.display_name ?? "Unnamed"} · {new Date(o.created_at).toLocaleString()}
                        </p>
                        <p className="text-[11px] text-muted-foreground font-mono mt-0.5">user: {o.user_id.slice(0, 8)}…</p>
                      </div>
                      <p className="text-sm font-semibold shrink-0 text-success">
                        ${Math.abs(Number(o.amount)).toFixed(2)}
                      </p>
                    </div>
                  ))}
                </div>
              )}
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Edit balance dialog */}
      <Dialog open={!!editUser} onOpenChange={(o) => !o && setEditUser(null)}>
        <DialogContent className="glass-strong">
          <DialogHeader>
            <DialogTitle>Edit balance</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-sm text-muted-foreground">{editUser?.display_name ?? editUser?.id}</p>
            <Label htmlFor="bal">New balance (USD)</Label>
            <Input id="bal" type="number" step="0.01" min="0" value={editBalance} onChange={(e) => setEditBalance(e.target.value)} className="bg-background/40 h-11" />
          </div>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setEditUser(null)}>Cancel</Button>
            <Button variant="hero" onClick={saveBalance} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : "Save"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  );
};

export default Admin;
