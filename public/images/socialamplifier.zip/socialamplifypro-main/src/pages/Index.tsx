import { useEffect } from "react";
import { Navbar } from "@/components/site/Navbar";
import { Hero } from "@/components/site/Hero";
import { Categories } from "@/components/site/Categories";
import { Features } from "@/components/site/Features";
import { HowItWorks } from "@/components/site/HowItWorks";
import { SocialProof } from "@/components/site/SocialProof";
import { CTA } from "@/components/site/CTA";
import { Footer } from "@/components/site/Footer";
import { RecentPurchases } from "@/components/site/RecentPurchases";

const Index = () => {
  useEffect(() => {
    document.title = "Social Amplifier — Digital Growth & Verification Tools";
    const desc = document.querySelector('meta[name="description"]');
    if (desc) desc.setAttribute("content", "All-in-one platform for digital growth, virtual verification numbers, social engagement, and creative services. Fast, secure, scalable.");
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main>
        <Hero />
        <Categories />
        <Features />
        <HowItWorks />
        <SocialProof />
        <CTA />
      </main>
      <Footer />
      <RecentPurchases />
    </div>
  );
};

export default Index;
