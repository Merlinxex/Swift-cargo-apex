import { useEffect } from "react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { ProductGrid } from "@/components/shop/ProductGrid";
import { callingProducts, CALLING_WHATSAPP } from "@/data/products";
import { PhoneCall } from "lucide-react";

const Calling = () => {
  useEffect(() => {
    document.title = "Calling — Virtual Numbers & Streaming | Social Amplifier";
    const desc = document.querySelector('meta[name="description"]');
    if (desc)
      desc.setAttribute(
        "content",
        "Buy virtual calling & SMS numbers (Textplus, Nextplus, Google Voice, eSIM) and Netflix accounts. Instant delivery via WhatsApp."
      );
  }, []);

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 sm:pt-36 pb-20">
        <section className="container">
          <div className="max-w-2xl mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-primary-glow mb-4">
              <PhoneCall className="h-3.5 w-3.5" /> Calling & Streaming
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
              Pick a service. <span className="text-gradient-brand">We'll handle the rest.</span>
            </h1>
            <p className="mt-4 text-muted-foreground">
              Tap any product to instantly deduct from your balance and continue the order on WhatsApp.
            </p>
          </div>

          <ProductGrid
            products={callingProducts}
            whatsappNumber={CALLING_WHATSAPP}
            buildMessage={(p) => `hi I want ${p.name}`}
          />
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Calling;
