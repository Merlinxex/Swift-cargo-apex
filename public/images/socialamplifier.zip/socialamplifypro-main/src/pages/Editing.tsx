import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Loader2, Wallet, ArrowRight, Sparkles } from "lucide-react";
import {
  editingProducts,
  EDITING_WHATSAPP,
  type ShopProduct,
} from "@/data/products";

// ─── Data ────────────────────────────────────────────────────────────────────

const individualServices = editingProducts.filter(
  (p) =>
    ![
      "package-starter",
      "package-growth",
      "package-elite",
      "addon-express",
      "addon-vip",
      "addon-revision",
      "addon-confidential",
    ].includes(p.id)
);

// Services where price is a "from" price
const fromPriceIds = new Set([
  "advanced-visual",
  "image-to-video",
  "document-editing",
  "image-editing",
]);

const serviceIcon: Record<string, string> = {
  "pet-placement": "🐾",
  "veterinary-scene": "🩺",
  "veterinary-bill": "📋",
  "vehicle-transport": "🚛",
  "custom-clearance": "🚗",
  "advanced-visual": "✏️",
  "image-to-video": "▶️",
  "drivers-license": "🪪",
  "ownership-transfer": "📄",
  "refund-documentation": "↩️",
  "document-editing": "📝",
  "image-editing": "🖼️",
};

const packages = [
  {
    id: "package-starter",
    name: "STARTER",
    subtitle: "Perfect for simple needs",
    price: 25,
    emoji: "📦",
    features: ["1 Scene / Edit", "Standard Quality", "1 Revision", "2-3 Days Delivery"],
    popular: false,
  },
  {
    id: "package-growth",
    name: "GROWTH",
    subtitle: "Best Value & Quality",
    price: 60,
    emoji: "⭐",
    features: [
      "3 Scenes / Edits",
      "High Quality",
      "Up to 2 Revisions",
      "Priority Support",
      "24-48H Delivery",
    ],
    popular: true,
  },
  {
    id: "package-elite",
    name: "ELITE",
    subtitle: "For the best results",
    price: 120,
    emoji: "🏆",
    features: [
      "1 Tracking Website",
      "All-Inclusive Services",
      "Premium Quality",
      "Unlimited Revisions",
      "VIP Priority",
      "12-24H Delivery",
    ],
    popular: false,
  },
];

// ─── Component ───────────────────────────────────────────────────────────────

const Editing = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const { toast } = useToast();
  const [balance, setBalance] = useState<number | null>(null);
  const [loadingId, setLoadingId] = useState<string | null>(null);

  // Sync SEO
  useEffect(() => {
    document.title =
      "Editing Services — Photo, Video & Documents | Social Amplifier";
    const desc = document.querySelector('meta[name="description"]');
    if (desc)
      desc.setAttribute(
        "content",
        "Pro photo & document editing: pet edits, car transport edits, image-to-video, IDs and more. Instant order via WhatsApp."
      );
  }, []);

  // Wallet subscription
  useEffect(() => {
    if (!user) {
      setBalance(null);
      return;
    }
    const load = async () => {
      const { data } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) setBalance(Number(data.balance));
    };
    void load();

    const channel = supabase
      .channel(`wallet-editing-${user.id}`)
      .on(
        "postgres_changes",
        {
          event: "*",
          schema: "public",
          table: "wallets",
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const next = (payload.new as { balance?: number } | null)?.balance;
          if (typeof next === "number") setBalance(Number(next));
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const handleBuy = async (p: ShopProduct) => {
    if (!user) {
      toast({ title: "Sign in required", description: "Please sign in to purchase." });
      navigate("/auth");
      return;
    }
    if (balance === null) {
      toast({ title: "Loading wallet…", description: "Please wait a moment." });
      return;
    }
    if (balance < p.price) {
      toast({
        title: "Insufficient balance",
        description: `You need $${p.price.toFixed(2)} but only have $${balance.toFixed(2)}. Top up your wallet.`,
        variant: "destructive",
      });
      return;
    }

    setLoadingId(p.id);
    let whatsappOpened = false;

    try {
      const message = `hi I want ${p.name}`;
      const url = `https://wa.me/${EDITING_WHATSAPP}?text=${encodeURIComponent(message)}`;
      const win = window.open(url, "_blank", "noopener,noreferrer");
      whatsappOpened = true;
      if (!win) window.location.href = url;

      const newBalance = Number((balance - p.price).toFixed(2));
      const { data: wallet } = await supabase
        .from("wallets")
        .select("total_spent")
        .eq("user_id", user.id)
        .maybeSingle();

      const { error: wErr } = await supabase
        .from("wallets")
        .update({
          balance: newBalance,
          total_spent: Number(wallet?.total_spent ?? 0) + p.price,
        })
        .eq("user_id", user.id);
      if (wErr) throw wErr;

      const { error: tErr } = await supabase.from("transactions").insert({
        user_id: user.id,
        type: "charge",
        amount: -p.price,
        description: `Purchase: ${p.name}`,
        metadata: {
          product_id: p.id,
          product_name: p.name,
          whatsapp: EDITING_WHATSAPP,
        },
      });
      if (tErr) throw tErr;

      setBalance(newBalance);
      toast({
        title: "Order confirmed",
        description: `$${p.price.toFixed(2)} deducted. WhatsApp opened.`,
      });
    } catch (e) {
      console.error(e);
      if (whatsappOpened) {
        toast({
          title: "Order confirmed",
          description: `$${p.price.toFixed(2)} deducted. WhatsApp opened.`,
        });
      } else {
        toast({
          title: "Order failed",
          description: e instanceof Error ? e.message : "Something went wrong.",
          variant: "destructive",
        });
      }
    } finally {
      setLoadingId(null);
    }
  };

  const getProduct = (id: string) =>
    editingProducts.find((p) => p.id === id)!;

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 sm:pt-36 pb-20">
        <section className="container">

          {/* Page header */}
          <div className="max-w-2xl mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-primary-glow mb-4">
              <Sparkles className="h-3.5 w-3.5" /> Editing Services
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
              Edits that{" "}
              <span className="text-gradient-brand">tell your story</span>
            </h1>
            <p className="mt-4 text-muted-foreground">
              Order an edit — your balance is charged instantly and we'll
              continue the brief on WhatsApp.
            </p>
          </div>

          {/* ── SERVICES LIST ── */}
          <div className="max-w-lg mb-16">
            <h2 className="text-center text-lg font-bold tracking-[0.18em] uppercase mb-6"
              style={{ color: "#c9a227" }}>
              OUR SERVICES
            </h2>

            <div className="rounded-xl overflow-hidden border border-white/8"
              style={{ background: "rgba(255,255,255,0.03)" }}>
              {individualServices.map((p, i) => {
                const isLoading = loadingId === p.id;
                const isFrom = fromPriceIds.has(p.id);
                return (
                  <div
                    key={p.id}
                    className="group flex items-center justify-between px-5 py-3.5 transition-colors hover:bg-white/5 cursor-pointer"
                    style={{
                      borderBottom:
                        i < individualServices.length - 1
                          ? "1px solid rgba(255,255,255,0.06)"
                          : "none",
                    }}
                    onClick={() => !isLoading && handleBuy(p)}
                  >
                    <div className="flex items-center gap-3.5">
                      <span className="text-lg w-6 text-center select-none">
                        {serviceIcon[p.id] ?? "✨"}
                      </span>
                      <span className="text-sm text-white/85 group-hover:text-white transition-colors">
                        {p.name}
                      </span>
                    </div>
                    <div className="flex items-center gap-3 ml-4 shrink-0">
                      <span className="text-sm font-bold" style={{ color: "#c9a227" }}>
                        {isFrom && (
                          <span className="text-white/40 font-normal text-xs mr-0.5">
                            from{" "}
                          </span>
                        )}
                        ${p.price}
                        {isFrom && "+"}
                      </span>
                      {isLoading ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-primary" />
                      ) : (
                        <ArrowRight className="h-3.5 w-3.5 text-white/20 group-hover:text-primary transition-colors" />
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* ── PACKAGES ── */}
          <div>
            <h2 className="text-center text-lg font-bold tracking-[0.18em] uppercase mb-10"
              style={{ color: "#c9a227" }}>
              CHOOSE YOUR PACKAGE
            </h2>

            <div className="flex flex-col sm:flex-row gap-5 justify-center items-center sm:items-end">
              {packages.map((pkg) => {
                const product = getProduct(pkg.id);
                const isLoading = loadingId === pkg.id;
                return (
                  <div
                    key={pkg.id}
                    className="relative rounded-2xl flex flex-col transition-all duration-300"
                    style={{
                      background: pkg.popular
                        ? "rgba(255,255,255,0.06)"
                        : "rgba(255,255,255,0.03)",
                      border: pkg.popular
                        ? "1.5px solid #c9a227"
                        : "1px solid rgba(255,255,255,0.1)",
                      boxShadow: pkg.popular
                        ? "0 0 32px rgba(201,162,39,0.18)"
                        : "none",
                      padding: pkg.popular ? "36px 28px 28px" : "28px 24px 24px",
                      width: pkg.popular ? 268 : 232,
                      transform: pkg.popular ? "translateY(-10px)" : "none",
                    }}
                  >
                    {/* Most Popular badge */}
                    {pkg.popular && (
                      <div
                        className="absolute left-1/2 -translate-x-1/2 text-[10px] font-bold tracking-widest uppercase px-4 py-1.5 rounded"
                        style={{
                          top: -16,
                          background: "#c9a227",
                          color: "#000",
                          whiteSpace: "nowrap",
                        }}
                      >
                        MOST POPULAR
                      </div>
                    )}

                    {/* Icon */}
                    <div className="text-center text-4xl mb-3">{pkg.emoji}</div>

                    {/* Name */}
                    <h3
                      className="text-center font-display font-bold tracking-widest uppercase mb-1.5"
                      style={{ fontSize: 18 }}
                    >
                      {pkg.name}
                    </h3>

                    {/* Subtitle */}
                    <p className="text-center text-xs text-muted-foreground mb-4">
                      {pkg.subtitle}
                    </p>

                    {/* Price */}
                    <p
                      className="text-center font-display font-bold mb-5"
                      style={{ fontSize: 44, color: "#c9a227", lineHeight: 1 }}
                    >
                      ${pkg.price}
                    </p>

                    {/* Features */}
                    <ul className="space-y-2 mb-7">
                      {pkg.features.map((f) => (
                        <li
                          key={f}
                          className="flex items-center gap-2.5 text-sm text-white/75"
                        >
                          <span style={{ color: "#c9a227", fontSize: 10 }}>●</span>
                          {f}
                        </li>
                      ))}
                    </ul>

                    {/* CTA */}
                    <button
                      disabled={isLoading}
                      onClick={() => !isLoading && handleBuy(product)}
                      className="w-full py-3 rounded-lg text-xs font-bold tracking-widest uppercase transition-all duration-200 disabled:opacity-50"
                      style={
                        pkg.popular
                          ? { background: "#c9a227", color: "#000", border: "none" }
                          : {
                              background: "transparent",
                              color: "#c9a227",
                              border: "1.5px solid #c9a227",
                            }
                      }
                      onMouseEnter={(e) => {
                        if (!pkg.popular) {
                          (e.currentTarget as HTMLButtonElement).style.background =
                            "#c9a227";
                          (e.currentTarget as HTMLButtonElement).style.color = "#000";
                        }
                      }}
                      onMouseLeave={(e) => {
                        if (!pkg.popular) {
                          (e.currentTarget as HTMLButtonElement).style.background =
                            "transparent";
                          (e.currentTarget as HTMLButtonElement).style.color = "#c9a227";
                        }
                      }}
                    >
                      {isLoading ? (
                        <span className="flex items-center justify-center gap-2">
                          <Loader2 className="h-3.5 w-3.5 animate-spin" />
                          Processing…
                        </span>
                      ) : (
                        "CHOOSE PLAN"
                      )}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Wallet balance */}
          {user && (
            <div className="mt-12 flex items-center justify-center gap-2 text-xs text-muted-foreground">
              <Wallet className="h-3.5 w-3.5" />
              Wallet balance:{" "}
              <span className="text-success font-semibold">
                ${(balance ?? 0).toFixed(2)}
              </span>
            </div>
          )}
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Editing;
