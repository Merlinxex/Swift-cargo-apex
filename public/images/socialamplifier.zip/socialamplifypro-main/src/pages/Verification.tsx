import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from "@/components/ui/dialog";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { countries, apps, appCategories, type Country, type VerificationApp } from "@/data/verification";
import {
  ShieldCheck, Search, Globe, Zap, Lock, RefreshCw, CheckCircle2, Clock,
  Smartphone, ArrowRight, Copy, Sparkles, Activity, Server, KeyRound,
  Loader2, MessageSquare, Star, ArrowUpDown, ChevronDown,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { fiveSimServiceCodes, fiveSimCountryCodes } from "@/data/fiveSimCodes";
import { smspoolServiceCodes, smspoolCountryCodes } from "@/data/smspoolCodes";

type RentalStatus = "idle" | "picking" | "waiting" | "received" | "expired" | "unavailable";

const MARKUP = 1.5;
const SMSPOOL_MARKUP = 1.25;

// GrizzlySMS service codes
const grizzlyServiceCodes: Record<string, string> = {
  whatsapp: "wa", telegram: "tg", google: "go", discord: "ds",
  instagram: "ig", facebook: "fb", tiktok: "lf", twitter: "tw",
  snapchat: "fu", linkedin: "tn", signal: "bw", viber: "vi",
  wechat: "we", uber: "ub", amazon: "am", paypal: "ts",
  tinder: "oi", openai: "ot", spotify: "sf", netflix: "nf",
  microsoft: "mm", apple: "ap", airbnb: "rp", binance: "bn",
};

// GrizzlySMS country codes
const grizzlyCountryCodes: Record<string, string> = {
  US: "187", "US-V": "12", GB: "16", RU: "0", CN: "3", IN: "22", ID: "6",
  PH: "4", BR: "73", MX: "54", KE: "8", ZA: "31", NG: "19",
  VN: "10", TH: "52", MY: "7", PK: "66", BD: "60", KH: "146",
  DE: "43", FR: "78", NL: "48", CA: "36", AU: "175", JP: "182",
  KR: "190", SG: "196", TR: "62", EG: "21", AE: "92", SA: "53",
  UA: "1", KZ: "2", PL: "15", CO: "87", AR: "39", CL: "151",
};

async function callGrizzly(params: Record<string, string>): Promise<string> {
  const url = new URL(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/grizzly-proxy`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
  });
  const json = await res.json();
  console.log("[GrizzlyProxy]", params.action, "→ HTTP", res.status, JSON.stringify(json));
  if (json?.error) throw new Error(`Proxy error: ${json.error}`);
  return (json?.raw as string) ?? "";
}

async function callFiveSim(params: Record<string, string>): Promise<string> {
  const url = new URL(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/fivesim-proxy`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
  });
  const json = await res.json();
  return (json?.raw as string) ?? "";
}

async function callSmsPool(params: Record<string, string>): Promise<string> {
  const url = new URL(`${import.meta.env.VITE_SUPABASE_URL}/functions/v1/smspool-proxy`);
  Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
  const res = await fetch(url.toString(), {
    headers: { Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}` },
  });
  const json = await res.json();
  return (json?.raw as string) ?? "";
}

type Provider = "grizzly" | "fivesim" | "smspool" | "random";

const INITIAL_VISIBLE = 8;

const Verification = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();

  const [serviceQuery, setServiceQuery] = useState("");
  const [countryQuery, setCountryQuery] = useState("");
  const [showAllServices, setShowAllServices] = useState(false);
  const [showAllCountries, setShowAllCountries] = useState(false);
  const [favoriteServices, setFavoriteServices] = useState<Set<string>>(new Set());
  const [favoriteCountries, setFavoriteCountries] = useState<Set<string>>(new Set());
  const [serviceSort, setServiceSort] = useState<"popular" | "price-asc" | "price-desc">("popular");

  const [selectedCountry, setSelectedCountry] = useState<Country | null>(null);
  const [selectedApp, setSelectedApp] = useState<VerificationApp | null>(null);

  const [rentalOpen, setRentalOpen] = useState(false);
  const [rentalStatus, setRentalStatus] = useState<RentalStatus>("idle");
  const [otp, setOtp] = useState<string>("");
  const [number, setNumber] = useState<string>("");
  const [seconds, setSeconds] = useState(120);
  const [tiers, setTiers] = useState<{ price: number; qty: number; providerId: string }[]>([]);

  useEffect(() => {
    document.title = "Virtual Numbers & OTP Verification • Social Amplify";
  }, []);

  const filteredCountries = useMemo(() => {
    const q = countryQuery.toLowerCase().trim();
    const list = countries.filter((c) => !q || c.name.toLowerCase().includes(q) || c.code.toLowerCase().includes(q));
    // favorites first, then popular, then alphabetical
    return [...list].sort((a, b) => {
      const fa = favoriteCountries.has(a.code) ? 1 : 0;
      const fb = favoriteCountries.has(b.code) ? 1 : 0;
      if (fa !== fb) return fb - fa;
      const pa = a.popular ? 1 : 0;
      const pb = b.popular ? 1 : 0;
      if (pa !== pb) return pb - pa;
      return a.name.localeCompare(b.name);
    });
  }, [countryQuery, favoriteCountries]);

  const filteredApps = useMemo(() => {
    const q = serviceQuery.toLowerCase().trim();
    const list = apps.filter((a) => !q || a.name.toLowerCase().includes(q));
    return [...list].sort((a, b) => {
      const fa = favoriteServices.has(a.id) ? 1 : 0;
      const fb = favoriteServices.has(b.id) ? 1 : 0;
      if (fa !== fb) return fb - fa;
      if (serviceSort === "price-asc") return a.basePrice - b.basePrice;
      if (serviceSort === "price-desc") return b.basePrice - a.basePrice;
      // popular: hot first, then success rate
      const ha = a.hot ? 1 : 0;
      const hb = b.hot ? 1 : 0;
      if (ha !== hb) return hb - ha;
      return b.successRate - a.successRate;
    });
  }, [serviceQuery, serviceSort, favoriteServices]);

  const visibleServices = selectedApp
    ? filteredApps.filter((a) => a.id === selectedApp.id)
    : showAllServices ? filteredApps : filteredApps.slice(0, INITIAL_VISIBLE);
  const visibleCountries = selectedCountry
    ? filteredCountries.filter((c) => c.code === selectedCountry.code)
    : showAllCountries ? filteredCountries : filteredCountries.slice(0, INITIAL_VISIBLE);

  const toggleFavoriteService = (id: string) => {
    setFavoriteServices((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id); else next.add(id);
      return next;
    });
  };
  const toggleFavoriteCountry = (code: string) => {
    setFavoriteCountries((prev) => {
      const next = new Set(prev);
      if (next.has(code)) next.delete(code); else next.add(code);
      return next;
    });
  };

  const [provider, setProvider] = useState<Provider>("grizzly");

  // Live operator tiers from GrizzlySMS
  type OperatorTier = { qty: number; price: number; operator?: string; providerId?: string };
  const [operatorTiers, setOperatorTiers] = useState<OperatorTier[]>([]);
  const [operatorTiersLoading, setOperatorTiersLoading] = useState(false);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [selectedTierOperator, setSelectedTierOperator] = useState<string>("any");
  const activationIdRef = useRef<string | null>(null);
  const pendingChargeRef = useRef<{ amount: number; description: string } | null>(null);

  // ── Wallet (mirrors ProductGrid pattern) ────────────────────────────────────
  const [walletBalance, setWalletBalance] = useState<number | null>(null);

  useEffect(() => {
    if (!user) { setWalletBalance(null); return; }
    const load = async () => {
      const { data } = await supabase
        .from("wallets")
        .select("balance")
        .eq("user_id", user.id)
        .maybeSingle();
      if (data) setWalletBalance(Number(data.balance));
    };
    void load();
    const channel = supabase
      .channel(`wallet-verification-${user.id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "wallets", filter: `user_id=eq.${user.id}` },
        (payload) => {
          const next = (payload.new as { balance?: number } | null)?.balance;
          if (typeof next === "number") setWalletBalance(Number(next));
        })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user]);

  // ── Deduct from wallets table and record transaction (mirrors ProductGrid) ──
  const deductBalance = useCallback(async (amount: number, description: string) => {
    if (walletBalance === null) throw new Error("wallet_not_loaded");
    if (walletBalance < amount) throw new Error("insufficient_balance");
    const newBalance = Number((walletBalance - amount).toFixed(2));

    const { data: wallet } = await supabase
      .from("wallets")
      .select("total_spent")
      .eq("user_id", user!.id)
      .maybeSingle();

    const { error: wErr } = await supabase
      .from("wallets")
      .update({ balance: newBalance, total_spent: Number(wallet?.total_spent ?? 0) + amount })
      .eq("user_id", user!.id);
    if (wErr) throw wErr;

    const { error: tErr } = await supabase.from("transactions").insert({
      user_id: user!.id,
      type: "charge",
      amount: -amount,
      description,
      metadata: { source: "verification" },
    });
    if (tErr) throw tErr;

    setWalletBalance(newBalance);
  }, [user, walletBalance]);

  // ── Refund balance (mirrors deductBalance in reverse) ───────────────────────
  const refundBalance = useCallback(async (amount: number, description: string) => {
    const { data: wallet } = await supabase
      .from("wallets")
      .select("total_spent")
      .eq("user_id", user!.id)
      .maybeSingle();

    await supabase
      .from("wallets")
      .update({
        balance: Number(((walletBalance ?? 0) + amount).toFixed(2)),
        total_spent: Math.max(0, Number(wallet?.total_spent ?? 0) - amount),
      })
      .eq("user_id", user!.id);

    await supabase.from("transactions").insert({
      user_id: user!.id,
      type: "refund",
      amount,
      description,
      metadata: { source: "verification" },
    });

    setWalletBalance((prev) => Number(((prev ?? 0) + amount).toFixed(2)));
    toast({ title: "Refunded", description: `$${amount.toFixed(2)} returned to your wallet.` });
  }, [user, walletBalance, toast]);

  const fetchOperatorTiers = useCallback(async (country: Country, app: VerificationApp, prov: Provider) => {
    setOperatorTiersLoading(true);
    setOperatorTiers([]);
    try {
      // Random uses Grizzly's catalog for display purposes; actual purchase picks at random.
      const effective: Provider = prov === "random" ? "grizzly" : prov;
      if (effective === "fivesim") {
        const svcCode = fiveSimServiceCodes[app.id];
        const cntCode = fiveSimCountryCodes[country.code];
        if (!svcCode || !cntCode) { setOperatorTiers([]); return; }
        const raw = await callFiveSim({ action: "getPrices", country: cntCode, product: svcCode });
        const parsed = JSON.parse(raw);
        const operatorMap = parsed?.[cntCode]?.[svcCode];
        if (!operatorMap || typeof operatorMap !== "object") { setOperatorTiers([]); return; }
        const tiers: OperatorTier[] = [];
        for (const [opName, opVal] of Object.entries(operatorMap as Record<string, any>)) {
          const cost = Number(opVal?.cost ?? opVal?.price ?? 0);
          const qty = Number(opVal?.count ?? opVal?.quantity ?? 0);
          if (cost > 0 && qty > 0) {
            tiers.push({ operator: opName, qty, price: Math.round(cost * MARKUP * 100) / 100 });
          }
        }
        // Sort highest price first (best quality), keep top 4
        setOperatorTiers(tiers.sort((a, b) => b.price - a.price).slice(0, 4));
      } else if (effective === "smspool") {
        // SMSPool has no standalone pricing lookup endpoint in its API.
        // Price is only returned at order time (POST /purchase/sms).
        // Show the app's base price as an indicative figure.
        const price = Math.round(app.basePrice * SMSPOOL_MARKUP * 100) / 100;
        setOperatorTiers([{ qty: country.available, price }]);
      } else {
        // getPricesV3: { country: { service: { providers: { name: { count, price, provider_id } } } } }
        // provider_id is used in getNumberV2 providerIds to pin the exact tier the user picks
        const svcCode = grizzlyServiceCodes[app.id];
        const cntCode = grizzlyCountryCodes[country.code];
        if (!svcCode || !cntCode) { setOperatorTiers([]); return; }

        const raw = await callGrizzly({ action: "getPricesV3", service: svcCode, country: cntCode });
        const parsed = JSON.parse(raw);
        const serviceData = parsed?.[cntCode]?.[svcCode];
        const providers = serviceData?.providers;

        const tiers: OperatorTier[] = [];

        if (providers && typeof providers === "object") {
          for (const [, prov] of Object.entries(providers as Record<string, any>)) {
            const qty = Number(prov?.count ?? 0);
            const priceArr = Array.isArray(prov?.price) ? prov.price : [prov?.price];
            const providerId = String(prov?.provider_id ?? "");
            if (!providerId || qty === 0) continue;
            for (const rawPrice of priceArr) {
              const cost = Number(rawPrice);
              if (cost > 0) {
                tiers.push({ qty, price: Math.round(cost * MARKUP * 100) / 100, providerId });
              }
            }
          }
        }

        // Fallback to V2 if V3 returned no providers
        if (tiers.length === 0) {
          const rawV2 = await callGrizzly({ action: "getPricesV2", service: svcCode, country: cntCode });
          const parsedV2 = JSON.parse(rawV2);
          const buckets = parsedV2?.[cntCode]?.[svcCode];
          if (buckets && typeof buckets === "object") {
            for (const [rawPrice, rawCount] of Object.entries(buckets as Record<string, unknown>)) {
              const cost = Number(rawPrice);
              const qty = Number(rawCount);
              if (cost > 0 && qty > 0) {
                tiers.push({ qty, price: Math.round(cost * MARKUP * 100) / 100 });
              }
            }
          }
        }

        // Sort highest price first (best quality), keep top 4
        setOperatorTiers(tiers.sort((a, b) => b.price - a.price).slice(0, 4));
      }
    } catch {
      setOperatorTiers([]);
    } finally {
      setOperatorTiersLoading(false);
    }
  }, []);

  useEffect(() => {
    if (selectedApp && selectedCountry) fetchOperatorTiers(selectedCountry, selectedApp, provider);
    else setOperatorTiers([]);
  }, [selectedApp, selectedCountry, provider, fetchOperatorTiers]);

  // Countdown timer — refund if timer expires with no SMS
  useEffect(() => {
    if (!rentalOpen || rentalStatus !== "waiting") return;
    if (seconds <= 0) {
      if (pendingChargeRef.current) {
        refundBalance(pendingChargeRef.current.amount, pendingChargeRef.current.description).catch(() => {});
        pendingChargeRef.current = null;
      }
      setRentalStatus("expired");
      return;
    }
    const t = setTimeout(() => setSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [rentalOpen, rentalStatus, seconds, refundBalance]);

  // Cleanup polling when dialog closes — refund if rental was in progress
  useEffect(() => {
    if (!rentalOpen) {
      if (pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
      }
      if (pendingChargeRef.current) {
        refundBalance(pendingChargeRef.current.amount, pendingChargeRef.current.description).catch(() => {});
        pendingChargeRef.current = null;
      }
      activationIdRef.current = null;
    }
  }, [rentalOpen, refundBalance]);

  const startRental = async (country: Country, app: VerificationApp, operator = "any", maxCost?: number) => {
    if (!user) {
      toast({ title: "Sign in required", description: "Create a free account to rent a number." });
      navigate("/auth");
      return;
    }
    if (walletBalance === null) {
      toast({ title: "Loading wallet…", description: "Please wait a moment and try again." });
      return;
    }

    setSelectedCountry(country);
    setSelectedApp(app);
    setOtp("");
    setNumber("—");
    setSeconds(120);
    setRentalStatus("idle");
    setRentalOpen(true);

    // Random: pick a provider at random per request
    const effProvider: Provider = provider === "random"
      ? (["grizzly", "fivesim", "smspool"] as Provider[])[Math.floor(Math.random() * 3)]
      : provider;
    if (provider === "random") {
      toast({ title: "Random provider", description: `Trying ${effProvider === "grizzly" ? "Turbo 1" : effProvider === "fivesim" ? "Turbo 2" : "Turbo 3"}…` });
    }

    try {
      if (effProvider === "smspool") {
        const svcCode = smspoolServiceCodes[app.id];
        const cntCode = smspoolCountryCodes[country.code];
        if (!svcCode || !cntCode) {
          setRentalStatus("expired");
          toast({ title: "Unsupported", description: "This service/country combo is not available on Turbo 3.", variant: "destructive" });
          return;
        }
        // Charge immediately before calling the provider
        const chargeAmountSmsPool = Math.round(app.basePrice * SMSPOOL_MARKUP * 100) / 100;
        try {
          await deductBalance(chargeAmountSmsPool, `Virtual number: ${app.name} (${country.name}) via Turbo 3`);
        } catch (err) {
          setRentalStatus("unavailable");
          const msg = err instanceof Error && err.message === "insufficient_balance"
            ? `You need $${chargeAmountSmsPool.toFixed(2)} but only have $${(walletBalance ?? 0).toFixed(2)}.`
            : "Could not deduct credits. Please try again.";
          toast({ title: "Payment failed", description: msg, variant: "destructive" });
          return;
        }

        // SMSPool: POST /purchase/sms — returns { success, number, orderid, ... }
        const raw = await callSmsPool({ action: "purchase/sms", service: svcCode, country: cntCode });
        let parsed: any = null;
        try { parsed = JSON.parse(raw); } catch { /* */ }
        if (parsed?.success === 1 && parsed?.number && parsed?.orderid) {
          activationIdRef.current = String(parsed.orderid);
          pendingChargeRef.current = { amount: chargeAmountSmsPool, description: `Refund: ${app.name} (${country.name}) — no SMS received` };
          setRentalStatus("waiting");
          setNumber(String(parsed.number));
          if (pollRef.current) clearInterval(pollRef.current);
          pollRef.current = setInterval(async () => {
            if (!activationIdRef.current) return;
            try {
              // SMSPool: POST /sms/check — returns { status: "success", sms: "code" }
              const statusRaw = await callSmsPool({ action: "sms/check", orderid: activationIdRef.current });
              const sp = JSON.parse(statusRaw);
              if (sp?.status === "success" && sp?.sms) {
                pendingChargeRef.current = null; // SMS received — no refund
                setOtp(String(sp.sms));
                setRentalStatus("received");
                clearInterval(pollRef.current!);
              }
            } catch { /* ignore */ }
          }, 5000);
        } else {
          setRentalStatus("unavailable");
          // Provider failed — refund immediately
          refundBalance(chargeAmountSmsPool, `Refund: ${app.name} (${country.name}) — no number available`).catch(() => {});
          const msg = String(parsed?.message ?? raw ?? "");
          const lower = msg.toLowerCase();
          if (lower.includes("no numbers") || lower.includes("out of stock") || lower.includes("unavailable")) {
            toast({ title: "No numbers available", description: "No numbers available — you have been refunded.", variant: "destructive" });
          } else {
            toast({ title: "SMSPool error", description: (msg || "Unexpected response.") + " You have been refunded.", variant: "destructive" });
          }
        }
      } else if (effProvider === "fivesim") {
        const svcCode = fiveSimServiceCodes[app.id];
        const cntCode = fiveSimCountryCodes[country.code];
        if (!svcCode || !cntCode) {
          setRentalStatus("expired");
          toast({ title: "Unsupported", description: "This service/country combo is not available on 5sim.", variant: "destructive" });
          return;
        }
        // Charge immediately before calling the provider
        const chargeAmountFiveSim = Math.round(app.basePrice * MARKUP * 100) / 100;
        try {
          await deductBalance(chargeAmountFiveSim, `Virtual number: ${app.name} (${country.name}) via Turbo 2`);
        } catch (err) {
          setRentalStatus("unavailable");
          const msg = err instanceof Error && err.message === "insufficient_balance"
            ? `You need $${chargeAmountFiveSim.toFixed(2)} but only have $${(walletBalance ?? 0).toFixed(2)}.`
            : "Could not deduct credits. Please try again.";
          toast({ title: "Payment failed", description: msg, variant: "destructive" });
          return;
        }

        // 5sim buy: { id, phone, operator, product, price, status, sms: [] }
        const raw = await callFiveSim({ action: "buyNumber", country: cntCode, operator, product: svcCode });
        let parsed: any = null;
        try { parsed = JSON.parse(raw); } catch { /* non-JSON error string */ }
        if (parsed?.phone) {
          activationIdRef.current = String(parsed.id);
          pendingChargeRef.current = { amount: chargeAmountFiveSim, description: `Refund: ${app.name} (${country.name}) — no SMS received` };
          setRentalStatus("waiting");
          setNumber(`+${parsed.phone}`);
          // Poll for SMS every 5s
          if (pollRef.current) clearInterval(pollRef.current);
          pollRef.current = setInterval(async () => {
            if (!activationIdRef.current) return;
            try {
              const statusRaw = await callFiveSim({ action: "checkSMS", id: activationIdRef.current });
              const statusParsed = JSON.parse(statusRaw);
              if (statusParsed?.sms?.length > 0) {
                const code = statusParsed.sms[statusParsed.sms.length - 1]?.code ?? statusParsed.sms[statusParsed.sms.length - 1]?.text ?? "";
                pendingChargeRef.current = null; // SMS received — no refund
                setOtp(code);
                setRentalStatus("received");
                clearInterval(pollRef.current!);
                // Finish the activation
                callFiveSim({ action: "finishNumber", id: activationIdRef.current }).catch(() => {});
              } else if (statusParsed?.status === "CANCELED" || statusParsed?.status === "TIMEOUT") {
                if (pendingChargeRef.current) {
                  refundBalance(pendingChargeRef.current.amount, pendingChargeRef.current.description).catch(() => {});
                  pendingChargeRef.current = null;
                }
                setRentalStatus("expired");
                clearInterval(pollRef.current!);
              }
            } catch { /* ignore poll errors */ }
          }, 5000);
        } else {
          setRentalStatus("unavailable");
          // Provider failed — refund immediately
          refundBalance(chargeAmountFiveSim, `Refund: ${app.name} (${country.name}) — no number available`).catch(() => {});
          const msg = parsed?.message || raw || "Unexpected response from 5sim.";
          const lower = String(msg).toLowerCase();
          if (lower.includes("no free phones")) {
            toast({ title: "No numbers available", description: "No numbers available — you have been refunded.", variant: "destructive" });
          } else {
            toast({ title: "Error", description: String(msg) + " You have been refunded.", variant: "destructive" });
          }
        }
      } else {
        // ── GrizzlySMS ──
        const svcCode = grizzlyServiceCodes[app.id];
        const cntCode = grizzlyCountryCodes[country.code];

        if (!svcCode || !cntCode) {
          setRentalStatus("unavailable");
          toast({ title: "Unsupported", description: "This service/country combo is not available.", variant: "destructive" });
          return;
        }

        // Pre-flight: validate API key and region
        const balanceRaw = await callGrizzly({ action: "getBalance" });
        if (!balanceRaw || balanceRaw === "BAD_KEY") {
          setRentalStatus("unavailable");
          toast({ title: "API key error", description: "GrizzlySMS API key is invalid or missing.", variant: "destructive" });
          return;
        }
        if (balanceRaw === "SERVICE_UNAVAILABLE_REGION") {
          setRentalStatus("unavailable");
          toast({ title: "Region blocked", description: "GrizzlySMS is blocking requests from your Supabase region.", variant: "destructive" });
          return;
        }

        // If the user already picked a tier from the main page, rent immediately
        if (operator && operator !== "any" && maxCost) {
          await rentWithTier(operator, maxCost, country, app);
          return;
        }

        // Otherwise fetch tiers via getPricesV3 and show the picker in the modal
        const priceRaw = await callGrizzly({ action: "getPricesV3", service: svcCode, country: cntCode });
        let parsed: any = null;
        try { parsed = JSON.parse(priceRaw); } catch { /* fall through */ }

        const providers = parsed?.[cntCode]?.[svcCode]?.providers;
        const loadedTiers: { price: number; qty: number; providerId: string }[] = [];

        if (providers && typeof providers === "object") {
          for (const [, prov] of Object.entries(providers as Record<string, any>)) {
            const qty = Number(prov?.count ?? 0);
            const providerId = String(prov?.provider_id ?? "");
            const priceArr = Array.isArray(prov?.price) ? prov.price : [prov?.price];
            for (const rawPrice of priceArr) {
              const cost = Number(rawPrice);
              if (cost > 0 && qty > 0 && providerId) {
                loadedTiers.push({
                  price: Math.round(cost * MARKUP * 100) / 100,
                  qty,
                  providerId,
                });
              }
            }
          }
        }

        if (loadedTiers.length === 0) {
          setRentalStatus("unavailable");
          toast({ title: "No numbers available", description: "No tiers available for this service/country right now.", variant: "destructive" });
          return;
        }

        loadedTiers.sort((a, b) => a.price - b.price);
        setTiers(loadedTiers);
        setRentalStatus("picking");
      }
    } catch (e) {
      setRentalStatus(number === "—" ? "unavailable" : "expired");
      toast({ title: "Connection error", description: "Could not reach the provider. Try again.", variant: "destructive" });
    }
  };

  const rentWithTier = async (providerId: string, price: number, country?: Country, app?: VerificationApp) => {
    const rentCountry = country ?? selectedCountry;
    const rentApp = app ?? selectedApp;
    if (!rentCountry || !rentApp) return;
    setRentalStatus("waiting");

    const svcCode = grizzlyServiceCodes[rentApp.id];
    const cntCode = grizzlyCountryCodes[rentCountry.code];
    const rawCost = Math.round((price / MARKUP) * 100) / 100;

    // Charge immediately before calling the provider
    try {
      await deductBalance(price, `Virtual number: ${rentApp.name} (${rentCountry.name}) via Turbo 1`);
    } catch (err) {
      setRentalStatus("unavailable");
      const msg = err instanceof Error && err.message === "insufficient_balance"
        ? `You need $${price.toFixed(2)} but only have $${(walletBalance ?? 0).toFixed(2)}.`
        : "Could not deduct credits. Please try again.";
      toast({ title: "Payment failed", description: msg, variant: "destructive" });
      return;
    }

    let raw = "";
    try {
      raw = await callGrizzly({
        action: "getNumberV2",
        service: svcCode,
        country: cntCode,
        maxPrice: String(rawCost),
        providerIds: providerId,
      });
    } catch (e) {
      setRentalStatus("unavailable");
      toast({ title: "Connection error", description: "Could not reach GrizzlySMS. Try again.", variant: "destructive" });
      return;
    }

    let activationId = "";
    let phone = "";

    // getNumberV2 returns JSON
    try {
      const json = JSON.parse(raw);
      if (json?.activationId && (json?.phoneNumber || json?.phone)) {
        activationId = String(json.activationId);
        phone = String(json.phoneNumber ?? json.phone);
      }
    } catch { /* not JSON */ }

    // Fallback: legacy plain-text ACCESS_NUMBER:id:phone
    if (!activationId && raw.startsWith("ACCESS_NUMBER:")) {
      const parts = raw.split(":");
      activationId = parts[1];
      phone = parts[2];
    }

    if (activationId && phone) {
      activationIdRef.current = activationId;
      pendingChargeRef.current = { amount: price, description: `Refund: ${rentApp.name} (${rentCountry.name}) — no SMS received` };
      setNumber(`+${phone}`);

      if (pollRef.current) clearInterval(pollRef.current);
      pollRef.current = setInterval(async () => {
        if (!activationIdRef.current) return;
        try {
          const statusRaw = await callGrizzly({ action: "getStatus", id: activationIdRef.current });
          if (statusRaw.startsWith("STATUS_OK:")) {
            pendingChargeRef.current = null; // SMS received — no refund
            setOtp(statusRaw.split(":")[1] ?? "");
            setRentalStatus("received");
            clearInterval(pollRef.current!);
          } else if (statusRaw === "STATUS_CANCEL") {
            if (pendingChargeRef.current) {
              refundBalance(pendingChargeRef.current.amount, pendingChargeRef.current.description).catch(() => {});
              pendingChargeRef.current = null;
            }
            setRentalStatus("expired");
            clearInterval(pollRef.current!);
          }
        } catch { /* ignore transient poll errors */ }
      }, 5000);

    } else if (raw === "NO_NUMBERS") {
      refundBalance(price, `Refund: ${rentApp.name} (${rentCountry.name}) — no number available`).catch(() => {});
      setRentalStatus("unavailable");
      toast({ title: "No numbers available", description: "This tier just ran out — you have been refunded.", variant: "destructive" });
    } else if (raw === "NO_BALANCE") {
      refundBalance(price, `Refund: ${rentApp.name} (${rentCountry.name}) — provider error`).catch(() => {});
      setRentalStatus("unavailable");
      toast({ title: "Provider error", description: "GrizzlySMS has no numbers — you have been refunded.", variant: "destructive" });
    } else {
      refundBalance(price, `Refund: ${rentApp.name} (${rentCountry.name}) — unexpected error`).catch(() => {});
      setRentalStatus("expired");
      toast({ title: "Unexpected response", description: (raw || "No response from GrizzlySMS.") + " You have been refunded.", variant: "destructive" });
    }
  };

  const quickRent = (country: Country) => {
    const defaultApp = apps.find((a) => a.id === "whatsapp")!;
    startRental(country, defaultApp);
  };

  const quickRentApp = (app: VerificationApp) => {
    const defaultCountry = countries.find((c) => c.code === "US")!;
    startRental(defaultCountry, app);
  };

  return (
    <main className="min-h-screen relative">
      <div className="absolute inset-0 pointer-events-none" style={{ background: "var(--gradient-hero)" }} />
      <Navbar />

      <div className="relative pt-32 pb-12 sm:pb-16">
        <div className="container">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass border border-border/60 text-xs font-medium mb-5">
              <ShieldCheck className="h-3.5 w-3.5 text-primary-glow" />
              <span className="text-muted-foreground">Verification Tools</span>
              <span className="h-1 w-1 rounded-full bg-success animate-pulse" />
              <span className="text-success">82 countries online</span>
            </div>
            <h1 className="font-display text-4xl sm:text-6xl font-bold tracking-tight leading-[1.05]">
              Virtual numbers for <span className="text-gradient-brand">instant OTP</span> across 200+ services.
            </h1>
            <p className="text-base sm:text-lg text-muted-foreground mt-5 max-w-2xl">
              Receive SMS codes for WhatsApp, Telegram, Google, Discord and any platform — in seconds.
              Pay per-use, in bulk, or via API. No SIM. No setup. Fully private.
            </p>

            <div className="flex flex-wrap items-center gap-3 mt-7">
              <Button variant="hero" size="lg" onClick={() => document.getElementById("catalog")?.scrollIntoView({ behavior: "smooth" })}>
                <Smartphone className="h-4 w-4" /> Get a number
              </Button>
              <Button variant="glass" size="lg" onClick={() => document.getElementById("api")?.scrollIntoView({ behavior: "smooth" })}>
                <KeyRound className="h-4 w-4" /> API access
              </Button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-10">
              {[
                { Icon: Globe, label: "Countries", value: "82+" },
                { Icon: Zap, label: "Avg delivery", value: "< 8s" },
                { Icon: Activity, label: "Success rate", value: "98%" },
                { Icon: Server, label: "API uptime", value: "99.99%" },
              ].map((s) => (
                <div key={s.label} className="glass rounded-xl p-3 sm:p-4 border border-border/60">
                  <s.Icon className="h-4 w-4 text-primary-glow mb-2" />
                  <p className="font-display font-bold text-lg sm:text-xl">{s.value}</p>
                  <p className="text-[11px] text-muted-foreground uppercase tracking-wider">{s.label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Catalog */}
      <section id="catalog" className="relative py-12 sm:py-16">
        <div className="container">
          <div className="mb-8">
            <p className="text-sm font-medium text-primary-glow mb-3 tracking-wider uppercase">Live catalog</p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight">
              Pick a service <span className="text-gradient-brand">and country</span>.
            </h2>
            <p className="text-sm text-muted-foreground mt-3 max-w-xl">
              Numbers are sourced live from our partner network. Star your favorites for quick access.
            </p>
          </div>

          {/* Provider Toggle */}
          <div className="flex justify-center mb-6">
            <div className="inline-flex flex-wrap items-center gap-1 p-1 rounded-xl glass border border-border/60">
              {([
                { id: "grizzly", label: "⚡ Turbo 1" },
                { id: "fivesim", label: "🚀 Turbo 2" },
                { id: "smspool", label: "🛰️ Turbo 3" },
                { id: "random", label: "🎲 Random" },
              ] as { id: Provider; label: string }[]).map((p) => (
                <button
                  key={p.id}
                  onClick={() => { setProvider(p.id); setOperatorTiers([]); }}
                  className={cn(
                    "px-4 py-1.5 rounded-lg text-sm font-medium transition-all",
                    provider === p.id
                      ? "bg-primary text-primary-foreground shadow-glow"
                      : "text-muted-foreground hover:text-foreground"
                  )}
                >
                  {p.label}
                </button>
              ))}
            </div>
          </div>

          {/* Selection bar */}
          {(selectedApp || selectedCountry) && (
            <Card className="glass-strong border-primary/30 rounded-2xl p-4 mb-6 flex flex-wrap items-center justify-between gap-3 shadow-glow">
              <div className="flex items-center gap-2 text-sm flex-wrap">
                <span className="text-muted-foreground">Selected:</span>
                {selectedApp && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-primary/15 border border-primary/30 text-foreground font-medium">
                    <Smartphone className="h-3 w-3" /> {selectedApp.name}
                  </span>
                )}
                {selectedCountry && (
                  <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-accent-violet/15 border border-accent-violet/30 text-foreground font-medium">
                    <span>{selectedCountry.flag}</span> {selectedCountry.name}
                  </span>
                )}
              </div>
              <Button
                variant="hero"
                size="sm"
                disabled={!selectedApp || !selectedCountry}
                onClick={() => selectedApp && selectedCountry && startRental(selectedCountry, selectedApp)}
              >
                Rent number <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </Card>
          )}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 lg:gap-6">
            {/* Service column */}
            <Card className="glass border-border/60 rounded-2xl overflow-hidden">
              <div className="p-4 sm:p-5 border-b border-border/60 flex items-center justify-between gap-3">
                <h3 className="font-display font-semibold text-base sm:text-lg">
                  <span className="text-primary-glow">1.</span> Select service
                </h3>
                <button
                  onClick={() => setServiceSort((s) => s === "popular" ? "price-asc" : s === "price-asc" ? "price-desc" : "popular")}
                  className="h-8 w-8 grid place-items-center rounded-lg border border-border bg-background/40 text-muted-foreground hover:text-primary-glow hover:border-primary/40 transition-colors"
                  title={`Sort: ${serviceSort === "popular" ? "Popular" : serviceSort === "price-asc" ? "Price ↑" : "Price ↓"}`}
                >
                  <ArrowUpDown className="h-3.5 w-3.5" />
                </button>
              </div>
              <div className="p-4 sm:p-5 border-b border-border/60">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-primary-glow" />
                  <Input
                    placeholder="Find website or app"
                    value={serviceQuery}
                    onChange={(e) => { setServiceQuery(e.target.value); setShowAllServices(true); }}
                    className="pl-9 h-11 rounded-full bg-background/40 border-border focus-visible:border-primary"
                  />
                </div>
              </div>
              <div className="divide-y divide-border/60 max-h-[480px] overflow-y-auto">
                {visibleServices.map((a) => {
                  const isSelected = selectedApp?.id === a.id;
                  const isFav = favoriteServices.has(a.id);
                  return (
                    <button
                      key={a.id}
                      onClick={() => setSelectedApp(prev => prev?.id === a.id ? null : a)}
                      className={cn(
                        "w-full flex items-center gap-3 p-3 sm:px-5 sm:py-3.5 text-left transition-colors",
                        isSelected ? "bg-primary/10 border-l-2 border-primary" : "hover:bg-card/60"
                      )}
                    >
                      <button
                        type="button"
                        onClick={(e) => { e.stopPropagation(); toggleFavoriteService(a.id); }}
                        className="shrink-0 p-1 -m-1 text-muted-foreground hover:text-warning transition-colors"
                        aria-label="Favorite service"
                      >
                        <Star className={cn("h-4 w-4", isFav && "fill-warning text-warning")} />
                      </button>
                      <div className="h-8 w-8 sm:h-9 sm:w-9 rounded-lg bg-gradient-aurora grid place-items-center shrink-0 shadow-glow">
                        <Smartphone className="h-3.5 w-3.5 text-primary-foreground" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="font-medium text-sm truncate">{a.name}</p>
                        <p className="text-[11px] text-muted-foreground capitalize">{a.category}</p>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="flex items-baseline gap-1 justify-end">
                          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">from</span>
                          <span className="font-display font-bold text-sm text-foreground">${a.basePrice.toFixed(2)}</span>
                        </div>
                        <p className="text-[10px] text-success mt-0.5">{a.successRate}% success</p>
                      </div>
                    </button>
                  );
                })}
                {filteredApps.length === 0 && (
                  <p className="text-center text-sm text-muted-foreground py-10">No services match your search.</p>
                )}
              </div>
              {!selectedApp && filteredApps.length > INITIAL_VISIBLE && (
                <button
                  onClick={() => setShowAllServices((v) => !v)}
                  className="w-full py-3.5 text-sm font-medium text-primary-glow hover:bg-card/40 border-t border-border/60 inline-flex items-center justify-center gap-1.5 transition-colors"
                >
                  {showAllServices ? "Show less" : `Show all ${filteredApps.length}`}
                  <ChevronDown className={cn("h-4 w-4 transition-transform", showAllServices && "rotate-180")} />
                </button>
              )}
              {selectedApp && (
                <button
                  onClick={() => setSelectedApp(null)}
                  className="w-full py-3.5 text-sm font-medium text-primary-glow hover:bg-card/40 border-t border-border/60 inline-flex items-center justify-center gap-1.5 transition-colors"
                >
                  Change service
                </button>
              )}
            </Card>

            {/* Country column */}
            <Card className="glass border-border/60 rounded-2xl overflow-hidden">
              <div className="p-4 sm:p-5 border-b border-border/60">
                <h3 className="font-display font-semibold text-base sm:text-lg">
                  <span className="text-accent-violet">2.</span> Select country
                </h3>
              </div>
              <div className="p-4 sm:p-5 border-b border-border/60">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-accent-violet" />
                  <Input
                    placeholder="Find country"
                    value={countryQuery}
                    onChange={(e) => { setCountryQuery(e.target.value); setShowAllCountries(true); }}
                    className="pl-9 h-11 rounded-full bg-background/40 border-border focus-visible:border-accent-violet"
                  />
                </div>
              </div>
              <div className="divide-y divide-border/60 max-h-[480px] overflow-y-auto">
                {visibleCountries.map((c) => {
                  const isSelected = selectedCountry?.code === c.code;
                  const isFav = favoriteCountries.has(c.code);
                  return (
                    <div key={c.code}>
                      <button
                        onClick={() => { if (!selectedApp) { toast({ title: "Select a service first", description: "Please pick a service before choosing a country." }); return; } setSelectedCountry(prev => prev?.code === c.code ? null : c); }}
                        className={cn(
                          "w-full flex items-center gap-3 p-3 sm:px-5 sm:py-3.5 text-left transition-colors",
                          isSelected ? "bg-accent-violet/10" : "hover:bg-card/60"
                        )}
                      >
                        <button
                          type="button"
                          onClick={(e) => { e.stopPropagation(); toggleFavoriteCountry(c.code); }}
                          className="shrink-0 p-1 -m-1 text-muted-foreground hover:text-warning transition-colors"
                          aria-label="Favorite country"
                        >
                          <Star className={cn("h-4 w-4", isFav && "fill-warning text-warning")} />
                        </button>
                        <span className="text-2xl leading-none shrink-0">{c.flag}</span>
                        <div className="min-w-0 flex-1">
                          <p className="font-medium text-sm truncate">{c.name}</p>
                          <p className="text-[11px] text-muted-foreground uppercase tracking-wider">{c.code}</p>
                        </div>
                        <div className="text-right shrink-0 flex items-center gap-1.5">
                          <div>
                            <p className="text-[11px] font-semibold text-accent-violet">
                              {isSelected && operatorTiers.length > 0
                                ? `from $${operatorTiers[0].price.toFixed(2)}`
                                : `from $${c.price.toFixed(2)}`}
                            </p>
                            <p className="text-[10px] text-success mt-0.5 inline-flex items-center gap-1">
                              <span className="h-1 w-1 rounded-full bg-success" />
                              {c.available.toLocaleString()}
                            </p>
                          </div>
                          <ChevronDown className={cn("h-4 w-4 text-accent-violet transition-transform", isSelected && "rotate-180")} />
                        </div>
                      </button>

                      {isSelected && (
                        <div className="bg-background/30 border-t border-border/40">
                          <div className="flex items-center justify-between px-5 py-2 border-b border-border/30">
                            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Quantity Available</span>
                            <span className="text-[10px] uppercase tracking-wider text-muted-foreground font-semibold">Price</span>
                          </div>
                          {operatorTiersLoading ? (
                            <div className="flex items-center justify-center gap-2 py-5 text-sm text-muted-foreground">
                              <Loader2 className="h-4 w-4 animate-spin text-primary-glow" />
                              Fetching live prices…
                            </div>
                          ) : operatorTiers.length === 0 ? (
                            <div className="py-5 text-center text-sm text-muted-foreground">
                              {selectedApp ? "No pricing data available." : "Select a service first."}
                            </div>
                          ) : (
                            operatorTiers.map((tier, idx) => (
                              <div key={idx} className="flex items-center justify-between px-5 py-3 border-b border-border/20 last:border-0">
                                <p className="text-sm text-foreground">
                                  <span className="font-semibold">{tier.qty > 0 ? tier.qty.toLocaleString() : "—"}</span>
                                  <span className="text-muted-foreground"> available</span>
                                </p>
                                <button
                                  onClick={() => startRental(c, selectedApp ?? apps[0], tier.providerId ?? "any", tier.price)}
                                  className="px-4 py-1.5 rounded-xl bg-primary text-primary-foreground font-semibold text-sm shadow-glow hover:opacity-90 transition-opacity"
                                >
                                  ${tier.price.toFixed(2)}
                                </button>
                              </div>
                            ))
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
                {filteredCountries.length === 0 && (
                  <p className="text-center text-sm text-muted-foreground py-10">No countries match your search.</p>
                )}
              </div>
              {!selectedCountry && filteredCountries.length > INITIAL_VISIBLE && (
                <button
                  onClick={() => setShowAllCountries((v) => !v)}
                  className="w-full py-3.5 text-sm font-medium text-accent-violet hover:bg-card/40 border-t border-border/60 inline-flex items-center justify-center gap-1.5 transition-colors"
                >
                  {showAllCountries ? "Show less" : `Show all ${filteredCountries.length}`}
                  <ChevronDown className={cn("h-4 w-4 transition-transform", showAllCountries && "rotate-180")} />
                </button>
              )}
              {selectedCountry && (
                <button
                  onClick={() => setSelectedCountry(null)}
                  className="w-full py-3.5 text-sm font-medium text-accent-violet hover:bg-card/40 border-t border-border/60 inline-flex items-center justify-center gap-1.5 transition-colors"
                >
                  Change country
                </button>
              )}
            </Card>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="relative py-16">
        <div className="container">
          <div className="text-center mb-12">
            <p className="text-sm font-medium text-primary-glow mb-3 tracking-wider uppercase">How it works</p>
            <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight">
              From rental to <span className="text-gradient-brand">verified</span> in 60 seconds.
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            {[
              { Icon: Globe, title: "Pick country", text: "Choose from 82+ regions with live availability." },
              { Icon: Smartphone, title: "Get a number", text: "Instantly assigned, valid for the chosen window." },
              { Icon: MessageSquare, title: "Receive OTP", text: "Code lands in your inbox within seconds." },
              { Icon: RefreshCw, title: "Auto-refund", text: "If no SMS arrives, the rental is voided automatically." },
            ].map((s, i) => (
              <Card key={s.title} className="glass border-border/60 rounded-2xl p-5 relative">
                <div className="absolute top-3 right-4 font-display font-bold text-3xl text-primary/30">0{i + 1}</div>
                <div className="h-10 w-10 rounded-xl bg-gradient-aurora grid place-items-center shadow-glow mb-3">
                  <s.Icon className="h-4 w-4 text-primary-foreground" />
                </div>
                <h3 className="font-display font-semibold">{s.title}</h3>
                <p className="text-sm text-muted-foreground mt-1.5">{s.text}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* API */}
      <section id="api" className="relative py-16">
        <div className="container">
          <Card className="glass-strong border-border/60 rounded-3xl overflow-hidden">
            <div className="grid lg:grid-cols-2 gap-0">
              <div className="p-8 sm:p-10">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass border border-border/60 text-xs font-medium mb-4">
                  <KeyRound className="h-3.5 w-3.5 text-primary-glow" />
                  <span className="text-muted-foreground">REST API • 99.99% uptime</span>
                </div>
                <h2 className="font-display text-3xl sm:text-4xl font-bold tracking-tight">
                  Automate at <span className="text-gradient-brand">any scale</span>.
                </h2>
                <p className="text-muted-foreground mt-4">
                  Spin up numbers programmatically, route SMS to webhooks, and rotate through countries with a single endpoint. Built for QA teams, growth ops, and high-volume verification.
                </p>
                <ul className="space-y-2.5 mt-6">
                  {[
                    "Rotate through 80+ countries automatically",
                    "Webhook delivery for incoming SMS",
                    "Concurrent requests with no rate limits on Pro",
                    "Auto-refund failed rentals via API",
                  ].map((f) => (
                    <li key={f} className="flex items-start gap-2.5 text-sm">
                      <CheckCircle2 className="h-4 w-4 text-success shrink-0 mt-0.5" /> {f}
                    </li>
                  ))}
                </ul>
                <div className="flex gap-3 mt-7">
                  <Button variant="hero" onClick={() => navigate(user ? "/dashboard" : "/auth")}>
                    {user ? "Get API key" : "Create account"} <ArrowRight className="h-4 w-4" />
                  </Button>
                  <Button variant="glass">View docs</Button>
                </div>
              </div>
              <div className="bg-background/40 border-l border-border/60 p-6 sm:p-8 font-mono text-xs sm:text-sm">
                <div className="flex items-center gap-1.5 mb-4">
                  <span className="h-2.5 w-2.5 rounded-full bg-destructive/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-warning/70" />
                  <span className="h-2.5 w-2.5 rounded-full bg-success/70" />
                  <span className="ml-2 text-muted-foreground">POST /v1/numbers/rent</span>
                </div>
                <pre className="whitespace-pre-wrap leading-relaxed text-muted-foreground">
{`curl -X POST https://api.socialamplify.io/v1/numbers/rent \\
  -H "Authorization: Bearer `}<span className="text-primary-glow">sa_live_••••</span>{`" \\
  -H "Content-Type: application/json" \\
  -d '{
    "country": "US",
    "service": "whatsapp",
    "ttl": 600
  }'

`}<span className="text-success">// 200 OK</span>{`
{
  "id": "num_8tQzR2",
  "number": "+1 415 552 0198",
  "country": "US",
  "service": "whatsapp",
  "expires_at": "2026-04-25T15:21:08Z",
  "webhook": "https://you.com/sms"
}`}
                </pre>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Trust */}
      <section className="relative py-16">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {[
              { Icon: Lock, title: "Privacy first", text: "Numbers are never reused for the same service. No KYC, no logs of your codes." },
              { Icon: RefreshCw, title: "Auto-refunds", text: "Didn't receive an SMS within the rental window? Credits are returned automatically." },
              { Icon: Sparkles, title: "Always-on stock", text: "Live capacity dashboards across 82+ countries. We rotate carriers in real time." },
            ].map((b) => (
              <Card key={b.title} className="glass border-border/60 rounded-2xl p-6">
                <div className="h-10 w-10 rounded-xl bg-gradient-aurora grid place-items-center shadow-glow mb-3">
                  <b.Icon className="h-4 w-4 text-primary-foreground" />
                </div>
                <h3 className="font-display font-semibold">{b.title}</h3>
                <p className="text-sm text-muted-foreground mt-1.5">{b.text}</p>
              </Card>
            ))}
          </div>
          <div className="text-center mt-12">
            <Link to="/" className="text-sm text-muted-foreground hover:text-foreground">← Back to all services</Link>
          </div>
        </div>
      </section>

      <Footer />

      {/* Rental Modal */}
      <Dialog open={rentalOpen} onOpenChange={setRentalOpen}>
        <DialogContent className="glass-strong border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="font-display text-xl">
              {rentalStatus === "picking" ? "Choose a tier" : rentalStatus === "received" ? "Code received 🎉" : rentalStatus === "expired" ? "Rental expired" : rentalStatus === "unavailable" ? "Not available" : "Waiting for SMS…"}
            </DialogTitle>
            <DialogDescription>
              {selectedCountry && selectedApp && (
                <>
                  {selectedCountry.flag} {selectedCountry.name} • {selectedApp.name}
                </>
              )}
            </DialogDescription>
          </DialogHeader>

          {rentalStatus !== "unavailable" && rentalStatus !== "picking" && (
          <div className="rounded-xl border border-border bg-background/40 p-4 my-2">
            <p className="text-[11px] uppercase tracking-wider text-muted-foreground">Your number</p>
            <div className="flex items-center justify-between mt-1">
              <p className="font-mono font-semibold text-base">{number}</p>
              <button
                onClick={() => { navigator.clipboard.writeText(number); toast({ title: "Copied", description: "Number copied to clipboard." }); }}
                className="p-1.5 rounded-md hover:bg-card text-muted-foreground hover:text-foreground"
              >
                <Copy className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
          )}

          {rentalStatus === "picking" && (
            <div className="flex flex-col gap-2 my-2">
              <p className="text-xs text-muted-foreground mb-1">Select a price tier to continue</p>
              {tiers.map((tier, i) => (
                <button
                  key={tier.providerId + i}
                  onClick={() => rentWithTier(tier.providerId, tier.price)}
                  className="flex items-center justify-between rounded-xl border border-border bg-background/40 px-4 py-3 hover:bg-card transition-colors text-sm"
                >
                  <span className="text-muted-foreground">{tier.qty.toLocaleString()} available</span>
                  <span className="font-semibold">${tier.price.toFixed(2)}</span>
                </button>
              ))}
            </div>
          )}

          {rentalStatus === "waiting" && (
            <div className="rounded-xl border border-dashed border-border bg-card/40 p-6 text-center">
              <Loader2 className="h-6 w-6 animate-spin text-primary-glow mx-auto mb-3" />
              <p className="text-sm text-muted-foreground">Listening for incoming SMS…</p>
              <p className="text-[11px] text-muted-foreground mt-2 inline-flex items-center gap-1">
                <Clock className="h-3 w-3" /> Expires in {Math.floor(seconds / 60)}:{String(seconds % 60).padStart(2, "0")}
              </p>
            </div>
          )}

          {rentalStatus === "received" && (
            <div className="rounded-xl border border-success/40 bg-success/5 p-5 text-center">
              <p className="text-[11px] uppercase tracking-wider text-success mb-2">Verification code</p>
              <p className="font-display font-bold text-4xl tracking-[0.3em] text-gradient">{otp}</p>
              <Button
                variant="glass"
                size="sm"
                className="mt-4"
                onClick={() => { navigator.clipboard.writeText(otp); toast({ title: "Copied", description: "Code copied." }); }}
              >
                <Copy className="h-3.5 w-3.5" /> Copy code
              </Button>
            </div>
          )}

          {rentalStatus === "expired" && (
            <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-5 text-center text-sm text-muted-foreground">
              No SMS received. Your credit has been refunded automatically.
            </div>
          )}

          {rentalStatus === "unavailable" && (
            <div className="rounded-xl border border-destructive/40 bg-destructive/5 p-5 text-center text-sm text-muted-foreground">
              No numbers are available for this service and country right now. No charge was made — try a different country or check back shortly.
            </div>
          )}

          <div className="flex gap-2 mt-2">
            <Button variant="outline" className="flex-1" onClick={() => setRentalOpen(false)}>Close</Button>
            {rentalStatus !== "waiting" && rentalStatus !== "picking" && (
              <Button
                variant="hero"
                className="flex-1"
                onClick={() => {
                  if (selectedCountry && selectedApp) startRental(selectedCountry, selectedApp);
                }}
              >
                <RefreshCw className="h-3.5 w-3.5" /> New number
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
};

export default Verification;
