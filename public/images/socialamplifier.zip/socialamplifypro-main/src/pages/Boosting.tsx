import { useEffect, useState } from "react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import {
  TrendingUp, ChevronDown, Flame, Sparkles, Star, AlertCircle,
  Instagram, Music2, Youtube, Facebook, MessageCircle, Heart,
  Eye, Users, Share2, Bookmark, type LucideIcon,
} from "lucide-react";
import { cn } from "@/lib/utils";

const WHATSAPP_NUMBER = "674449818";

const badgeStyle = {
  Hot: { Icon: Flame, cls: "bg-destructive/15 text-destructive border-destructive/30" },
  New: { Icon: Sparkles, cls: "bg-success/15 text-success border-success/30" },
  Popular: { Icon: Star, cls: "bg-warning/15 text-warning border-warning/30" },
  Limited: { Icon: AlertCircle, cls: "bg-accent-violet/15 text-accent-violet border-accent-violet/30" },
} as const;

type Badge = keyof typeof badgeStyle;

interface BoostService {
  name: string;
  icon: LucideIcon;
  description: string;
  badge?: Badge;
}

interface Platform {
  id: string;
  name: string;
  icon: LucideIcon;
  color: string;
  badge?: Badge;
  services: BoostService[];
}

const platforms: Platform[] = [
  {
    id: "instagram",
    name: "Instagram",
    icon: Instagram,
    color: "from-pink-500 to-purple-600",
    badge: "Hot",
    services: [
      { name: "Followers", icon: Users, description: "Real-looking followers with drip-feed delivery. 30-day refill guarantee." },
      { name: "Followers (Non Drop)", icon: Users, description: "Stable followers with 365-day refill protection.", badge: "Popular" },
      { name: "Likes", icon: Heart, description: "Fast likes delivery on any post or reel.", badge: "Hot" },
      { name: "Likes (Non Drop)", icon: Heart, description: "High-retention likes that stay long term." },
      { name: "Views", icon: Eye, description: "Boost your post reach and impressions instantly." },
      { name: "Reel Views", icon: Eye, description: "Push your reels to the explore page with view boosts.", badge: "New" },
      { name: "Story Views", icon: Eye, description: "Increase story view count and poll votes." },
      { name: "Comments", icon: MessageCircle, description: "Custom, random or emoji comments on your posts." },
      { name: "Saves", icon: Bookmark, description: "Post saves signal high-value content to the algorithm." },
      { name: "Shares", icon: Share2, description: "Post and reel shares for maximum reach amplification." },
    ],
  },
  {
    id: "tiktok",
    name: "TikTok",
    icon: Music2,
    color: "from-black to-pink-500",
    badge: "Popular",
    services: [
      { name: "Followers", icon: Users, description: "VIP and standard follower packages for fast growth.", badge: "Hot" },
      { name: "Likes", icon: Heart, description: "High-quality likes with ultra-fast delivery." },
      { name: "Views", icon: Eye, description: "Monetization-safe views from our own servers.", badge: "Popular" },
      { name: "Likes + Views", icon: Eye, description: "Combined package for maximum engagement boost." },
      { name: "Comments", icon: MessageCircle, description: "Custom comments to boost social proof." },
    ],
  },
  {
    id: "facebook",
    name: "Facebook",
    icon: Facebook,
    color: "from-blue-600 to-blue-400",
    services: [
      { name: "Page Followers", icon: Users, description: "Grow your Facebook page with real-looking followers." },
      { name: "Page Likes", icon: Heart, description: "Page likes + followers combo for maximum credibility.", badge: "Popular" },
      { name: "Post Likes", icon: Heart, description: "Fast post likes delivery with guaranteed retention." },
      { name: "Post Reactions", icon: Heart, description: "All reaction types — like, love, haha, wow, sad, angry." },
      { name: "Post Comments", icon: MessageCircle, description: "High quality custom or random comments." },
      { name: "Video Views", icon: Eye, description: "Video and Reels views with fast delivery.", badge: "Hot" },
      { name: "Story Views", icon: Eye, description: "Increase your story reach and visibility." },
      { name: "Shares", icon: Share2, description: "Post shares to amplify your content reach." },
      { name: "Group Members", icon: Users, description: "Real-looking group member additions.", badge: "New" },
    ],
  },
  {
    id: "youtube",
    name: "YouTube",
    icon: Youtube,
    color: "from-red-600 to-red-400",
    badge: "New",
    services: [
      { name: "Subscribers", icon: Users, description: "Grow your channel with high-retention subscribers." },
      { name: "Views", icon: Eye, description: "Monetization-safe views with watch time included.", badge: "Hot" },
      { name: "Likes", icon: Heart, description: "Video likes to boost ranking and credibility." },
      { name: "Comments", icon: MessageCircle, description: "Custom comments from real-looking accounts." },
      { name: "Watch Hours", icon: Eye, description: "Boost watch hours toward monetization threshold.", badge: "Popular" },
    ],
  },
];

const Boosting = () => {
  const [expanded, setExpanded] = useState<string | null>(null);

  useEffect(() => {
    document.title = "Boosting — Social Growth Packs | Social Amplifier";
    const desc = document.querySelector('meta[name="description"]');
    if (desc)
      desc.setAttribute(
        "content",
        "Followers, likes, views and comments for Instagram, TikTok, Facebook and YouTube. Safe, drip-fed delivery."
      );
  }, []);

  const openWhatsApp = (platform: string, service: string) => {
    const msg = encodeURIComponent(
      `Hi, I'd like to order *${service}* for *${platform}*. Please assist me.`
    );
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`, "_blank");
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 sm:pt-36 pb-20">
        <section className="container">
          {/* Header */}
          <div className="max-w-2xl mb-10">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-primary-glow mb-4">
              <TrendingUp className="h-3.5 w-3.5" /> Social Boosting
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
              Boost reach. <span className="text-gradient-brand">Win the algorithm.</span>
            </h1>
            <p className="mt-4 text-muted-foreground">
              Real engagement bursts for Instagram, TikTok, Facebook and YouTube. Click a platform to see available services.
            </p>
          </div>

          {/* Platform list */}
          <div className="flex flex-col gap-3">
            {platforms.map((platform) => {
              const PlatformIcon = platform.icon;
              const isOpen = expanded === platform.id;
              const badge = platform.badge ? badgeStyle[platform.badge] : null;

              return (
                <div
                  key={platform.id}
                  className="rounded-2xl glass border border-border/60 overflow-hidden transition-all duration-300"
                >
                  {/* Platform row */}
                  <button
                    onClick={() => setExpanded(isOpen ? null : platform.id)}
                    className="w-full flex items-center gap-4 p-5 text-left hover:bg-white/[0.03] transition-colors"
                  >
                    <div className={cn("h-11 w-11 rounded-xl bg-gradient-to-br grid place-items-center shadow-glow flex-shrink-0", platform.color)}>
                      <PlatformIcon className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-display font-semibold text-lg">{platform.name}</p>
                      <p className="text-xs text-muted-foreground">{platform.services.length} services available</p>
                    </div>
                    {badge && (
                      <span className={cn("hidden sm:inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-semibold border uppercase tracking-wider", badge.cls)}>
                        <badge.Icon className="h-3 w-3" /> {platform.badge}
                      </span>
                    )}
                    <ChevronDown className={cn("h-5 w-5 text-muted-foreground transition-transform duration-300 flex-shrink-0", isOpen && "rotate-180")} />
                  </button>

                  {/* Services sub-list */}
                  {isOpen && (
                    <div className="border-t border-border/40">
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-px bg-border/20">
                        {platform.services.map((svc) => {
                          const SvcIcon = svc.icon;
                          const svcBadge = svc.badge ? badgeStyle[svc.badge] : null;
                          return (
                            <button
                              key={svc.name}
                              onClick={() => openWhatsApp(platform.name, svc.name)}
                              className="flex items-start gap-3 p-4 text-left bg-background/40 hover:bg-primary/5 hover:border-primary/20 transition-all group"
                            >
                              <div className="h-9 w-9 rounded-lg bg-primary/10 grid place-items-center flex-shrink-0 group-hover:bg-primary/20 transition-colors">
                                <SvcIcon className="h-4 w-4 text-primary-glow" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <div className="flex items-center gap-2 flex-wrap">
                                  <p className="font-medium text-sm">{svc.name}</p>
                                  {svcBadge && (
                                    <span className={cn("inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full text-[9px] font-semibold border uppercase tracking-wider", svcBadge.cls)}>
                                      <svcBadge.Icon className="h-2.5 w-2.5" /> {svc.badge}
                                    </span>
                                  )}
                                </div>
                                <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{svc.description}</p>
                              </div>
                              <div className="text-xs text-primary-glow opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 pt-0.5">
                                Order →
                              </div>
                            </button>
                          );
                        })}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </section>
      </main>
      <Footer />
    </div>
  );
};

export default Boosting;
