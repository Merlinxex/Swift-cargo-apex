import { useEffect, useState } from "react";
import { Navbar } from "@/components/site/Navbar";
import { Footer } from "@/components/site/Footer";
import { MessageCircle, ChevronDown, ShieldCheck, Zap, RefreshCw, Wallet, Phone, HelpCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";

const SUPPORT_WHATSAPP = "674449818";

const faqs = [
  {
    category: "Orders & Delivery",
    icon: Zap,
    items: [
      {
        q: "How quickly will my order be processed?",
        a: "Most orders are processed within minutes. Once you tap Order, WhatsApp opens automatically and our team picks up from there — usually within a few minutes during business hours.",
      },
      {
        q: "What happens after I place an order?",
        a: "Your balance is deducted and WhatsApp opens with a pre-filled message to our team. Just send it and we'll take care of the rest. No extra steps needed.",
      },
      {
        q: "Can I cancel an order after placing it?",
        a: "If you haven't received your service yet, message us on WhatsApp right away and we'll do our best to cancel and refund. Once delivery has started we may not be able to reverse it.",
      },
    ],
  },
  {
    category: "Payments & Refunds",
    icon: Wallet,
    items: [
      {
        q: "How do refunds work?",
        a: "Refunds are returned directly to your wallet balance, usually instantly. For virtual numbers, if no SMS is received within the rental window your credits are returned automatically.",
      },
      {
        q: "My balance was deducted but nothing happened — what do I do?",
        a: "Message us on WhatsApp support below with your account email and the service you ordered. We'll verify and refund within minutes if something went wrong.",
      },
      {
        q: "How do I top up my wallet?",
        a: "Head to your Dashboard and tap Top Up. We accept card payments and various local methods depending on your region.",
      },
    ],
  },
  {
    category: "Virtual Numbers",
    icon: Phone,
    items: [
      {
        q: "Why didn't I receive an SMS code?",
        a: "Some platforms block virtual numbers or take a few extra seconds to deliver. If the rental window expires without a code, your credits are refunded automatically. Try a different country or provider and try again.",
      },
      {
        q: "Can I reuse a number?",
        a: "Numbers are single-use per service for privacy and security. Each rental gives you a fresh number that hasn't been used for that service before.",
      },
      {
        q: "Which provider should I choose?",
        a: "Turbo 1 (GrizzlySMS) has the widest country coverage. Turbo 2 (5sim) is great for specific regions. Turbo 3 (SMSPool) is a reliable backup. Try Random if you're not sure.",
      },
    ],
  },
  {
    category: "Account & Security",
    icon: ShieldCheck,
    items: [
      {
        q: "Is my data safe?",
        a: "Yes. We don't store SMS codes, log your verifications, or share your data with third parties. Numbers are never reused for the same service across different users.",
      },
      {
        q: "I can't sign in to my account — what do I do?",
        a: "Try resetting your password from the sign-in page. If you're still locked out, contact us on WhatsApp with your account email and we'll sort it out.",
      },
    ],
  },
];

const FaqItem = ({ q, a }: { q: string; a: string }) => {
  const [open, setOpen] = useState(false);
  return (
    <div
      className={cn(
        "border border-border/60 rounded-xl overflow-hidden transition-all duration-300",
        open ? "bg-card/60" : "bg-background/30 hover:bg-background/50"
      )}
    >
      <button
        className="w-full flex items-center justify-between gap-4 px-5 py-4 text-left"
        onClick={() => setOpen(!open)}
      >
        <span className="text-sm font-medium leading-snug">{q}</span>
        <ChevronDown
          className={cn(
            "h-4 w-4 text-muted-foreground shrink-0 transition-transform duration-300",
            open && "rotate-180"
          )}
        />
      </button>
      <div
        className={cn(
          "overflow-hidden transition-all duration-300",
          open ? "max-h-48" : "max-h-0"
        )}
      >
        <p className="px-5 pb-5 text-sm text-muted-foreground leading-relaxed">{a}</p>
      </div>
    </div>
  );
};

const FAQ = () => {
  useEffect(() => {
    document.title = "FAQ & Customer Support • Social Amplifier";
  }, []);

  const openWhatsApp = () => {
    const url = `https://wa.me/${SUPPORT_WHATSAPP}?text=${encodeURIComponent("Hi, I need help with my order.")}`;
    const win = window.open(url, "_blank", "noopener,noreferrer");
    if (!win) window.location.href = url;
  };

  return (
    <div className="min-h-screen">
      <Navbar />
      <main className="pt-32 sm:pt-36 pb-20">

        {/* Hero */}
        <section className="container mb-16">
          <div className="max-w-2xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full glass text-xs text-primary-glow mb-4">
              <HelpCircle className="h-3.5 w-3.5" /> FAQ & Customer Support
            </div>
            <h1 className="font-display text-3xl sm:text-5xl font-bold tracking-tight">
              How can we <span className="text-gradient-brand">help you?</span>
            </h1>
            <p className="mt-4 text-muted-foreground">
              Browse common questions below, or reach out directly on WhatsApp — we typically reply within a few minutes.
            </p>
          </div>
        </section>

        {/* WhatsApp support card */}
        <section className="container mb-16">
          <div className="relative rounded-2xl glass-strong border border-primary/30 p-6 sm:p-8 overflow-hidden">
            <div className="absolute inset-0 bg-gradient-aurora opacity-[0.06] pointer-events-none" />
            <div className="relative flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 rounded-xl bg-[#25D366]/15 border border-[#25D366]/30 grid place-items-center shrink-0">
                  <MessageCircle className="h-6 w-6 text-[#25D366]" />
                </div>
                <div>
                  <p className="font-display font-semibold text-base">Chat with support on WhatsApp</p>
                  <p className="text-sm text-muted-foreground mt-0.5">
                    Real humans. Fast replies. No bots.
                  </p>
                </div>
              </div>
              <Button variant="hero" size="lg" onClick={openWhatsApp} className="shrink-0">
                <MessageCircle className="h-4 w-4" /> Start a chat
              </Button>
            </div>

            <div className="relative mt-6 pt-6 border-t border-border/60 grid grid-cols-1 sm:grid-cols-3 gap-4">
              {[
                { icon: Zap, label: "Avg. response time", value: "< 5 minutes" },
                { icon: RefreshCw, label: "Refund disputes", value: "Resolved same day" },
                { icon: ShieldCheck, label: "Availability", value: "7 days a week" },
              ].map((s) => (
                <div key={s.label} className="flex items-center gap-3">
                  <s.icon className="h-4 w-4 text-primary-glow shrink-0" />
                  <div>
                    <p className="text-[11px] uppercase tracking-wider text-muted-foreground">{s.label}</p>
                    <p className="text-sm font-semibold">{s.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* FAQ sections */}
        <section className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
            {faqs.map((section) => (
              <div key={section.category}>
                <div className="flex items-center gap-2 mb-4">
                  <section.icon className="h-4 w-4 text-primary-glow" />
                  <h2 className="font-display font-semibold text-sm uppercase tracking-wider text-primary-glow">
                    {section.category}
                  </h2>
                </div>
                <div className="flex flex-col gap-2">
                  {section.items.map((item) => (
                    <FaqItem key={item.q} q={item.q} a={item.a} />
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Bottom CTA */}
          <div className="mt-16 text-center">
            <p className="text-muted-foreground text-sm mb-4">Still have a question? We're one message away.</p>
            <Button variant="hero" size="lg" onClick={openWhatsApp}>
              <MessageCircle className="h-4 w-4" /> Chat on WhatsApp
            </Button>
          </div>
        </section>

      </main>
      <Footer />
    </div>
  );
};

export default FAQ;
