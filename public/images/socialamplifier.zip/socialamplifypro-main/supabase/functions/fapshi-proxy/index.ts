// Fapshi proxy: initiate payment + check status. Keeps API keys server-side.
const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
};

const FAPSHI_BASE = "https://live.fapshi.com";

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const apikey = Deno.env.get("FAPSHI_API_KEY");
  const apiuser = Deno.env.get("FAPSHI_API_USER");
  if (!apikey || !apiuser) {
    return jsonResponse({ error: "Fapshi credentials not configured" }, 500);
  }

  try {
    const body = await req.json().catch(() => ({}));
    const action = body.action as string;

    if (action === "initiate") {
      const { amountXaf, email, userId, externalId, message, redirectUrl } = body;
      if (!amountXaf || amountXaf < 100) {
        return jsonResponse({ error: "Minimum amount is 100 XAF" }, 400);
      }
      const payload: Record<string, unknown> = {
        amount: Math.round(Number(amountXaf)),
      };
      if (email) payload.email = email;
      if (userId) payload.userId = String(userId).slice(0, 50);
      if (externalId) payload.externalId = String(externalId).slice(0, 50);
      if (message) payload.message = String(message).slice(0, 100);
      if (redirectUrl) payload.redirectUrl = redirectUrl;

      const r = await fetch(`${FAPSHI_BASE}/initiate-pay`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          apikey,
          apiuser,
        },
        body: JSON.stringify(payload),
      });
      const data = await r.json().catch(() => ({}));
      return jsonResponse(data, r.status);
    }

    if (action === "status") {
      const { transId } = body;
      if (!transId) return jsonResponse({ error: "transId required" }, 400);
      const r = await fetch(`${FAPSHI_BASE}/payment-status/${encodeURIComponent(transId)}`, {
        headers: { apikey, apiuser },
      });
      const data = await r.json().catch(() => ({}));
      return jsonResponse(data, r.status);
    }

    return jsonResponse({ error: "Unknown action" }, 400);
  } catch (err) {
    return jsonResponse({ error: err instanceof Error ? err.message : "Server error" }, 500);
  }
});
