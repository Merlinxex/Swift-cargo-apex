import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const API_BASE = "https://5sim.net/v1";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("FIVESIM_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "FIVESIM_API_KEY not set" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const headers = {
      Authorization: `Bearer ${apiKey}`,
      Accept: "application/json",
    };

    const url = new URL(req.url);
    const action = url.searchParams.get("action");

    if (!action) {
      return new Response(JSON.stringify({ error: "missing action" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    let upstream: string;
    let raw: string;

    if (action === "getPrices") {
      // GET /v1/guest/prices?country={country}&product={product}
      // Returns: { "country": { "product": { "operatorName": { "cost": N, "count": N } } } }
      const country = url.searchParams.get("country");
      const product = url.searchParams.get("product");
      if (!country || !product) {
        return new Response(JSON.stringify({ error: "missing country or product" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      upstream = `${API_BASE}/guest/prices?country=${encodeURIComponent(country)}&product=${encodeURIComponent(product)}`;
      const res = await fetch(upstream, { headers });
      raw = await res.text();

    } else if (action === "buyNumber") {
      // GET /v1/user/buy/activation/{country}/{operator}/{product}
      const country = url.searchParams.get("country");
      const operator = url.searchParams.get("operator") ?? "any";
      const product = url.searchParams.get("product");
      if (!country || !product) {
        return new Response(JSON.stringify({ error: "missing country or product" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      upstream = `${API_BASE}/user/buy/activation/${encodeURIComponent(country)}/${encodeURIComponent(operator)}/${encodeURIComponent(product)}`;
      const res = await fetch(upstream, { method: "GET", headers });
      raw = await res.text();

    } else if (action === "checkOrder" || action === "checkSMS") {
      const id = url.searchParams.get("id");
      if (!id) {
        return new Response(JSON.stringify({ error: "missing id" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      upstream = `${API_BASE}/user/check/${encodeURIComponent(id)}`;
      const res = await fetch(upstream, { headers });
      raw = await res.text();

    } else if (action === "cancelOrder" || action === "finishNumber") {
      const id = url.searchParams.get("id");
      if (!id) {
        return new Response(JSON.stringify({ error: "missing id" }), {
          status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
        });
      }
      const path = action === "finishNumber" ? "finish" : "cancel";
      upstream = `${API_BASE}/user/${path}/${encodeURIComponent(id)}`;
      const res = await fetch(upstream, { method: "GET", headers });
      raw = await res.text();

    } else if (action === "getProfile") {
      upstream = `${API_BASE}/user/profile`;
      const res = await fetch(upstream, { headers });
      raw = await res.text();

    } else {
      return new Response(JSON.stringify({ error: "action not allowed" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    return new Response(JSON.stringify({ raw, status: 200 }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });

  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
