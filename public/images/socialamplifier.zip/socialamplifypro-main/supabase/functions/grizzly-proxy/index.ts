import { corsHeaders } from "https://esm.sh/@supabase/supabase-js@2.95.0/cors";

const API_BASE = "https://api.grizzlysms.com/stubs/handler_api.php";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get("GRIZZLY_API_KEY");
    if (!apiKey) {
      return new Response(JSON.stringify({ error: "GRIZZLY_API_KEY not set" }), {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const url = new URL(req.url);
    const action = url.searchParams.get("action");
    if (!action) {
      return new Response(JSON.stringify({ error: "missing action" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const allowed = [
      "getNumber",
      "getNumberV2",
      "getStatus",
      "getStatusV2",
      "setStatus",
      "getBalance",
      "getPrices",
      "getPricesV2",
      "getPricesV3",
      "getActiveActivations",
      "getCountries",
      "getServicesList",
    ];
    if (!allowed.includes(action)) {
      return new Response(JSON.stringify({ error: "action not allowed" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const upstream = new URL(API_BASE);
    upstream.searchParams.set("api_key", apiKey);
    url.searchParams.forEach((v, k) => {
      if (k !== "api_key") upstream.searchParams.set(k, v);
    });

    const res = await fetch(upstream.toString());
    const text = await res.text();

    return new Response(JSON.stringify({ raw: text, status: res.status }), {
      status: 200,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
