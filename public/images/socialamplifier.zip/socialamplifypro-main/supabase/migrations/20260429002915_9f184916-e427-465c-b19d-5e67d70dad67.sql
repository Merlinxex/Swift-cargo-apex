
-- 1. Ensure user (if exists) has admin role
INSERT INTO public.user_roles (user_id, role)
SELECT u.id, 'admin'::public.app_role
FROM auth.users u
WHERE lower(u.email) = 'betrandacex@gmail.com'
ON CONFLICT DO NOTHING;

-- 2. Trigger function that prevents deleting the primary admin role
CREATE OR REPLACE FUNCTION public.protect_primary_admin()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  primary_email constant text := 'betrandacex@gmail.com';
  target_email text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    SELECT lower(email) INTO target_email FROM auth.users WHERE id = OLD.user_id;
    IF target_email = primary_email AND OLD.role = 'admin'::public.app_role THEN
      RAISE EXCEPTION 'Cannot remove primary admin';
    END IF;
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    SELECT lower(email) INTO target_email FROM auth.users WHERE id = OLD.user_id;
    IF target_email = primary_email AND OLD.role = 'admin'::public.app_role AND NEW.role <> 'admin'::public.app_role THEN
      RAISE EXCEPTION 'Cannot downgrade primary admin';
    END IF;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS protect_primary_admin_trg ON public.user_roles;
CREATE TRIGGER protect_primary_admin_trg
BEFORE DELETE OR UPDATE ON public.user_roles
FOR EACH ROW EXECUTE FUNCTION public.protect_primary_admin();

-- 3. On new signup, if email matches primary, also grant admin
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $function$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  insert into public.user_roles (user_id, role)
  values (new.id, 'user');
  if lower(new.email) = 'betrandacex@gmail.com' then
    insert into public.user_roles (user_id, role)
    values (new.id, 'admin')
    on conflict do nothing;
  end if;
  insert into public.wallets (user_id, balance)
  values (new.id, 0);
  return new;
end;
$function$;
