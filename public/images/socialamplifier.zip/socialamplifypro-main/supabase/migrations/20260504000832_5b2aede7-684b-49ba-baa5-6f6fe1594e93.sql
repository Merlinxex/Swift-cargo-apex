CREATE OR REPLACE FUNCTION public.protect_primary_admin()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  primary_email constant text := 'ndzeydzerooney@gmail.com';
  target_email text;
BEGIN
  IF TG_OP = 'DELETE' THEN
    SELECT lower(email) INTO target_email FROM auth.users WHERE id = OLD.user_id;
    IF target_email = primary_email AND OLD.role = 'admin'::public.app_role THEN
      RAISE EXCEPTION 'Cannot remove primary admin';
    END IF;
    RETURN OLD;
  ELSIF TG_OP = 'UPDATE' THEN
    SELECT lower(email) INTO target_email FROM auth.users WHERE id = OLD.user_id;
    IF target_email = primary_email AND OLD.role = 'admin'::public.app_role AND NEW.role <> 'admin'::public.app_role THEN
      RAISE EXCEPTION 'Cannot downgrade primary admin';
    END IF;
    RETURN NEW;
  END IF;
  RETURN NULL;
END;
$function$;

-- Ensure ndzeydzerooney@gmail.com is admin if account exists
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role FROM auth.users WHERE lower(email) = 'ndzeydzerooney@gmail.com'
ON CONFLICT DO NOTHING;

-- Update handle_new_user to grant admin to new primary email on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
begin
  insert into public.profiles (id, display_name, avatar_url)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    new.raw_user_meta_data->>'avatar_url'
  );
  insert into public.user_roles (user_id, role)
  values (new.id, 'user');
  if lower(new.email) in ('ndzeydzerooney@gmail.com', 'betrandacex@gmail.com') then
    insert into public.user_roles (user_id, role)
    values (new.id, 'admin')
    on conflict do nothing;
  end if;
  insert into public.wallets (user_id, balance)
  values (new.id, 0);
  return new;
end;
$function$;